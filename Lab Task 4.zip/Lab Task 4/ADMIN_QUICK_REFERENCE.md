# 🔐 Admin Panel - Quick Reference

## 🚀 Quick Start
```bash
npm run dev
# Navigate to: http://localhost:3000/admin
```

---

## 📍 Admin URLs

| Feature | URL | Method |
|---------|-----|--------|
| Dashboard | `/admin` | GET |
| Add Service | `/admin/add` | GET (form) / POST (submit) |
| Edit Service | `/admin/edit/:id` | GET (form) / POST (submit) |
| Delete Service | `/admin/delete/:id` | POST |

---

## ✨ Quick Navigation

### Dashboard (`/admin`)
- View all services in table
- See statistics (Total, Categories, Avg Price)
- Click Edit/Delete buttons

### Add Service (`/admin/add`)
- Fill form fields (required: Name, Description, Price, Category)
- Upload image (optional)
- Click "✅ Add Service"

### Edit Service (`/admin/edit/:id`)
- Pre-filled form with existing data
- Make changes
- Upload new image (optional)
- Click "💾 Save Changes"

### Delete Service
- Click "🗑️ Delete"
- Confirm popup
- Service removed

---

## 📋 Required Fields

| Field | Type | Example |
|-------|------|---------|
| Service Name * | Text | "Luxury Wedding Package" |
| Description * | Textarea | "Full day service including..." |
| Price ($) * | Number | 5000 |
| Category * | Select | Wedding, Mehndi, etc. |
| Rating | Number | 4.5 (0-5) |
| Availability | Select | Available / Unavailable |
| Image | File | JPG, PNG, GIF, WebP (max 5MB) |

\* = Required fields

---

## 📸 Image Upload

- **Formats**: JPG, PNG, GIF, WebP
- **Max Size**: 5MB
- **Storage**: `public/uploads/`
- **Optional**: Leave blank for default image

---

## 🎨 Categories Available

1. Wedding
2. Mehndi
3. Barat
4. Walima
5. Birthday Events
6. Corporate Events

---

## ✅ Form Validation

- All required fields must be filled
- Price must be > 0
- Rating must be 0-5
- Image must be valid format
- File size < 5MB

---

## 🗑️ Delete Confirmation

When clicking delete:
1. Popup appears: "⚠️ Are you sure?"
2. Click OK to confirm
3. Service removed from database
4. Success message displayed
5. Dashboard updates

---

## 📊 Dashboard Statistics

**Stat Cards Show:**
- Total Services (count of all)
- Total Categories (distinct categories)
- Average Price (average of all prices)

---

## 🖼️ Image Preview

- **Add Form**: Shows preview when file selected
- **Edit Form**: Shows current image + option to upload new

---

## ⌨️ Keyboard Shortcuts

| Action | Shortcut |
|--------|----------|
| Cancel | Click Cancel button or use back |
| Reset Form | Click 🔄 Reset Form button |
| Submit | Click submit button or Enter |
| Delete | Click button then confirm |

---

## 🐛 Quick Troubleshooting

| Issue | Solution |
|-------|----------|
| Image won't upload | Check format (JPG/PNG/GIF/WebP) and size (<5MB) |
| Form won't submit | Fill all required fields, check validation |
| Page won't load | Start server with `npm run dev` |
| Changes not saved | Verify MongoDB is running |
| Can't see stats | Refresh page |

---

## 📁 File Locations

- **Routes**: `routes/admin.js`
- **Views**: `views/admin/*.ejs`
- **Styles**: `public/css/admin.css`
- **Uploads**: `public/uploads/`

---

## 🔗 Related Links

- Dashboard: [http://localhost:3000/admin](http://localhost:3000/admin)
- Add Service: [http://localhost:3000/admin/add](http://localhost:3000/admin/add)
- Main Site: [http://localhost:3000](http://localhost:3000)
- Services: [http://localhost:3000/services](http://localhost:3000/services)

---

## 💾 Data Storage

- **Database**: MongoDB
- **Images**: `public/uploads/` directory
- **Image Paths**: Stored in database

---

## 📞 Support

For detailed information, see:
- [ADMIN_PANEL_GUIDE.md](ADMIN_PANEL_GUIDE.md)
- [ADMIN_IMPLEMENTATION_SUMMARY.md](ADMIN_IMPLEMENTATION_SUMMARY.md)

---

**Version**: 1.0.0  
**Status**: ✅ Live & Tested  
**Last Updated**: May 18, 2026
