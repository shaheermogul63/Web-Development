# 🔐 Admin Panel - Setup & Usage Guide

## Overview
This guide explains how to use the Admin Panel for managing services/packages on your Majestic Marquee website.

---

## ✅ What's Been Implemented

### 1. **Admin Dashboard** (`/admin`)
   - View all services in a professional table
   - See key statistics: Total Services, Categories, Average Price
   - Quick action buttons for Edit and Delete
   - Search-friendly interface with status indicators

### 2. **CRUD Operations**
   - ✅ **Create**: Add new services with `/admin/add`
   - ✅ **Read**: View all services on dashboard
   - ✅ **Update**: Edit existing services with `/admin/edit/:id`
   - ✅ **Delete**: Remove services with confirmation popup

### 3. **Image Upload Integration**
   - 📸 Multer middleware for secure file uploads
   - Images stored in `public/uploads/` directory
   - File path automatically saved to database
   - Max file size: 5MB
   - Supported formats: JPG, PNG, GIF, WebP
   - Image preview before upload/after update

### 4. **Form Validation**
   - Client-side validation (real-time feedback)
   - Server-side validation (data integrity)
   - Prevents empty fields and invalid data
   - Price must be positive number
   - Rating between 0-5

### 5. **Security & UX Features**
   - Deletion confirmation popup to prevent accidents
   - Form reset functionality
   - Success/error messages after actions
   - Responsive design for mobile devices
   - Smooth animations and transitions

---

## 🚀 How to Access the Admin Panel

### Start the Server
```bash
npm start
# or for development with auto-reload
npm run dev
```

### Access Admin Panel
Open your browser and navigate to:
```
http://localhost:3000/admin
```

---

## 📋 Admin Panel Features

### Dashboard (/admin)
**View all services with:**
- Service image thumbnail
- Service name
- Category (with color badge)
- Price ($)
- Rating (0-5 stars)
- Availability status
- Edit & Delete buttons

**Statistics displayed:**
- Total number of services
- Total number of categories
- Average price of all services

---

### Add New Service (/admin/add)

**Form Fields:**
1. **Service Name** * (required)
   - Enter descriptive name
   - Example: "Premium Wedding Package"

2. **Description** * (required)
   - Detailed service information
   - Include what's included in the package

3. **Price ($)** * (required)
   - Must be a positive number
   - Supports decimal values (e.g., 999.99)

4. **Category** * (required)
   - Select from: Wedding, Mehndi, Barat, Walima, Birthday Events, Corporate Events

5. **Rating** (0-5) ⭐
   - Optional, defaults to 4.5
   - Must be between 0 and 5

6. **Availability**
   - Toggle: Available / Unavailable
   - Default: Available

7. **Upload Image**
   - Optional (uses default if not provided)
   - Formats: JPG, PNG, GIF, WebP
   - Max size: 5MB
   - Preview image before submission

**Actions:**
- ✅ Submit (Add Service)
- 🔄 Reset Form
- ❌ Cancel

---

### Edit Service (/admin/edit/:id)

**Features:**
- Form pre-populated with current service data
- Current image displayed with path shown
- Option to upload new image or keep existing
- Image preview for new upload
- All validations same as Add form

**Actions:**
- 💾 Save Changes
- 🔄 Reset Form (revert changes)
- ❌ Cancel

---

### Delete Service

**Safety Features:**
1. Click "🗑️ Delete" button
2. Confirmation popup appears
3. Confirm to proceed with deletion
4. Service removed from database
5. Dashboard automatically updates
6. Success message displayed

---

## 📁 Directory Structure

```
Assignment 4/
├── routes/
│   ├── services.js       (Services listing, pagination)
│   └── admin.js          (NEW: Admin CRUD operations)
├── views/
│   ├── admin-layout.ejs  (NEW: Admin page layout)
│   └── admin/
│       ├── dashboard.ejs      (NEW: List all services)
│       ├── add-service.ejs    (NEW: Add service form)
│       └── edit-service.ejs   (NEW: Edit service form)
├── public/
│   ├── uploads/          (NEW: Uploaded images stored here)
│   └── css/
│       └── admin.css     (NEW: Admin panel styling)
└── server.js             (UPDATED: Added admin routes)
```

---

## 🛠️ Technical Implementation

### Backend (Node.js/Express)
- **Framework**: Express.js
- **Database**: MongoDB with Mongoose
- **File Upload**: Multer middleware
- **Image Storage**: `public/uploads/` directory

### Frontend
- **Templating**: EJS
- **Validation**: JavaScript (client-side) + Express (server-side)
- **Styling**: CSS Grid & Flexbox
- **Interactivity**: Vanilla JavaScript (no dependencies)

### Database Schema (MongoDB)
```javascript
{
  serviceName: String (required),
  description: String (required),
  price: Number (required),
  category: String (required, enum),
  rating: Number (0-5, default: 4.5),
  availability: Boolean (default: true),
  image: String (file path),
  createdAt: Date (default: now)
}
```

---

## 🔒 File Upload Details

### Multer Configuration
- **Storage**: Disk storage (`public/uploads/`)
- **Filename**: `timestamp-randomId-originalName.ext`
- **File Filter**: Only image MIME types allowed
- **Size Limit**: 5MB per file

### Example Upload
```
Input:  event-photo.jpg (2.5MB)
Output: 1684384523456-987654321-event-photo.jpg
Path:   /uploads/1684384523456-987654321-event-photo.jpg
DB:     Saved to Service.image field
```

---

## ⚙️ Usage Examples

### Adding a New Service
1. Click "➕ Add Service" button or navigate to `/admin/add`
2. Fill in all required fields (marked with *)
3. Upload an image (optional)
4. Click "✅ Add Service"
5. Redirected to dashboard with success message
6. New service appears at top of list

### Editing a Service
1. On dashboard, find the service
2. Click "✏️ Edit" button
3. Modify any field
4. Upload new image if desired (optional)
5. Click "💾 Save Changes"
6. Redirected to dashboard with success message

### Deleting a Service
1. On dashboard, find the service
2. Click "🗑️ Delete" button
3. Confirm deletion in popup: "Are you sure?"
4. Service removed immediately
5. Table updates without page reload

---

## 🧪 Testing Checklist

- [ ] Access `/admin` dashboard loads correctly
- [ ] All services display in table
- [ ] Statistics cards show correct values
- [ ] Click "Add Service" opens form
- [ ] Form validation prevents empty submissions
- [ ] Image upload preview shows selected image
- [ ] Submit form successfully creates service
- [ ] New service appears in dashboard
- [ ] Click "Edit" on a service loads form with data
- [ ] Edit form pre-populates all fields correctly
- [ ] Update image and save changes
- [ ] Dashboard reflects updated data
- [ ] Delete button shows confirmation popup
- [ ] Deletion removes service from database
- [ ] Success/error messages display properly

---

## 🐛 Troubleshooting

### Images not uploading
- Check if `public/uploads/` directory exists
- Verify file size is under 5MB
- Ensure file format is supported (JPG, PNG, GIF, WebP)
- Check browser console for errors

### Form submission not working
- Verify all required fields are filled (marked with *)
- Check price is a positive number
- Ensure category is selected
- Look for validation error messages

### Database connection issues
- Verify MongoDB is running
- Check MONGODB_URI in environment variables
- See server console for error messages

### Styles not applying
- Hard refresh browser (Ctrl+F5)
- Check if `admin.css` is loaded
- Verify file path in `<link>` tag

---

## 📱 Responsive Design

The Admin Panel is fully responsive:
- **Desktop**: Full table with all columns
- **Tablet**: Optimized layout, stacked actions
- **Mobile**: Simplified view with horizontal scroll for table

---

## 🔄 File Upload Workflow

```
User selects file
        ↓
Multer validates (type, size)
        ↓
File saved to public/uploads/
        ↓
Filename stored in database (Service.image)
        ↓
Image accessible via /uploads/filename
```

---

## 📚 Related Files

- **Admin Routes**: `/routes/admin.js`
- **Admin Views**: `/views/admin/*.ejs`
- **Admin Styles**: `/public/css/admin.css`
- **Main Server**: `/server.js`
- **Service Model**: `/models/Service.js`

---

## 🎯 Next Steps (Optional Enhancements)

1. Add user authentication for admin access
2. Implement role-based access control
3. Add bulk operations (edit/delete multiple)
4. Implement service search/filter on dashboard
5. Add analytics and usage statistics
6. Create backup/export functionality
7. Add image optimization/compression
8. Implement audit logging

---

## ✨ Summary

Your Admin Panel is now complete with:
✅ Full CRUD operations
✅ Image upload functionality
✅ Form validation
✅ Responsive design
✅ Professional UI/UX
✅ Smooth animations
✅ Error handling

**Admin Panel URL**: `http://localhost:3000/admin`

Enjoy managing your services! 🎉
