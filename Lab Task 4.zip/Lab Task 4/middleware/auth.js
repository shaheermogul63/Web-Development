// ==========================================
// AUTHENTICATION MIDDLEWARE
// ==========================================
// This file contains middleware functions for user authentication
// and authorization checks

// ==========================================
// MIDDLEWARE: Check if user is logged in
// ==========================================
// Redirect to login page if user is not authenticated
const isLoggedIn = (req, res, next) => {
  if (!req.session.user) {
    req.flash('error', 'Please log in to access this page');
    return res.redirect('/auth/login');
  }
  next();
};

// ==========================================
// MIDDLEWARE: Check if user is admin
// ==========================================
// Verify that the logged-in user has admin role
// If not, redirect with access denied message
const isAdmin = (req, res, next) => {
  // First check if user is logged in
  if (!req.session.user) {
    req.flash('error', 'Please log in to access this page');
    return res.redirect('/auth/login');
  }

  // Check if user has admin role
  if (req.session.user.role !== 'admin') {
    req.flash('error', 'Access Denied: Admin privileges required. This area is restricted to administrators only.');
    return res.redirect('/');
  }

  next();
};

// ==========================================
// MIDDLEWARE: Redirect if already logged in
// ==========================================
// Prevent logged-in users from accessing login/register pages
const alreadyLoggedIn = (req, res, next) => {
  if (req.session.user) {
    return res.redirect('/');
  }
  next();
};

module.exports = {
  isLoggedIn,
  isAdmin,
  alreadyLoggedIn
};
