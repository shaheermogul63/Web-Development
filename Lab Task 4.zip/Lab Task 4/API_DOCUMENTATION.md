# RESTful API v1 Documentation

## Overview

This document describes the Majestic Marquee headless API (v1) for external clients like mobile apps and React frontends. The API uses JWT (JSON Web Tokens) for stateless authentication.

**Base URL:** `http://localhost:3000/api/v1`

---

## Authentication

### JWT Token Format
```
Authorization: Bearer <your_jwt_token>
```

All protected endpoints require the `Authorization` header with a valid JWT token.

### Token Expiration
Tokens expire after **24 hours**. Users need to re-login to get a new token.

### Token Payload
```json
{
  "user_id": "mongodb_user_id",
  "email": "user@example.com",
  "role": "customer" // or "admin"
}
```

---

## Authentication Endpoints

### 1. User Login
**Endpoint:** `POST /auth/login`

**Description:** Authenticate a user and receive a JWT token.

**Request Body:**
```json
{
  "email": "customer@example.com",
  "password": "password123"
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "customer@example.com",
      "role": "customer"
    }
  }
}
```

**Error Response (401):**
```json
{
  "success": false,
  "message": "Invalid email or password"
}
```

---

### 2. User Registration
**Endpoint:** `POST /auth/register`

**Description:** Create a new user account.

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "customer@example.com",
  "password": "password123",
  "confirmPassword": "password123"
}
```

**Success Response (201):**
```json
{
  "success": true,
  "message": "Registration successful. You are now logged in.",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "customer@example.com",
      "role": "customer"
    }
  }
}
```

**Error Response (409):**
```json
{
  "success": false,
  "message": "Email is already registered"
}
```

---

## Public Product Endpoints

### 3. Get All Products
**Endpoint:** `GET /products`

**Description:** Retrieve a list of all products/services with pagination and filtering.

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `category` (optional): Filter by category (Wedding, Mehndi, Barat, Walima, Birthday Events, Corporate Events)
- `search` (optional): Search in service name and description

**Examples:**
```
GET /products
GET /products?page=2&limit=5
GET /products?category=Wedding
GET /products?search=Luxury
GET /products?page=1&category=Wedding&search=Venue
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Products retrieved successfully",
  "data": {
    "products": [
      {
        "_id": "507f1f77bcf86cd799439011",
        "serviceName": "Premium Wedding Venue",
        "description": "Luxurious indoor venue perfect for weddings",
        "price": 50000,
        "category": "Wedding",
        "rating": 4.8,
        "availability": true,
        "image": "/images/venue.jpg",
        "createdAt": "2024-01-15T10:30:00Z"
      },
      {
        "_id": "507f1f77bcf86cd799439012",
        "serviceName": "Professional Photography",
        "description": "High-quality wedding photography services",
        "price": 25000,
        "category": "Wedding",
        "rating": 4.9,
        "availability": true,
        "image": "/images/photography.jpg",
        "createdAt": "2024-01-15T10:30:00Z"
      }
    ],
    "pagination": {
      "totalServices": 24,
      "currentPage": 1,
      "totalPages": 3,
      "hasNextPage": true,
      "hasPreviousPage": false
    }
  }
}
```

---

### 4. Get Single Product
**Endpoint:** `GET /products/:id`

**Description:** Retrieve details for a single product/service.

**Parameters:**
- `id` (required): MongoDB ObjectId of the product

**Example:**
```
GET /products/507f1f77bcf86cd799439011
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Product details retrieved successfully",
  "data": {
    "product": {
      "_id": "507f1f77bcf86cd799439011",
      "serviceName": "Premium Wedding Venue",
      "description": "Luxurious indoor venue perfect for weddings",
      "price": 50000,
      "category": "Wedding",
      "rating": 4.8,
      "availability": true,
      "image": "/images/venue.jpg",
      "createdAt": "2024-01-15T10:30:00Z"
    }
  }
}
```

**Error Response (404):**
```json
{
  "success": false,
  "message": "Product not found"
}
```

---

## Protected User Endpoints

### 5. Get User Profile
**Endpoint:** `GET /user/profile`

**Authentication:** Required (JWT Token)

**Description:** Retrieve authenticated user's profile information.

**Headers:**
```
Authorization: Bearer <your_jwt_token>
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "User profile retrieved successfully",
  "data": {
    "user": {
      "id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "customer@example.com",
      "role": "customer",
      "createdAt": "2024-01-15T08:00:00Z"
    }
  }
}
```

**Error Response (401):**
```json
{
  "success": false,
  "message": "Unauthorized: No authentication token provided"
}
```

---

## Protected Order Endpoints

### 6. Create Order
**Endpoint:** `POST /orders`

**Authentication:** Required (JWT Token)

**Description:** Create a new order for authenticated user.

**Headers:**
```
Authorization: Bearer <your_jwt_token>
```

**Request Body:**
```json
{
  "services": [
    {
      "serviceId": "507f1f77bcf86cd799439011",
      "serviceName": "Premium Wedding Venue",
      "price": 50000,
      "quantity": 1
    },
    {
      "serviceId": "507f1f77bcf86cd799439012",
      "serviceName": "Professional Photography",
      "price": 25000,
      "quantity": 1
    }
  ],
  "totalPrice": 75000,
  "eventDate": "2024-06-15T10:00:00Z",
  "eventType": "Wedding",
  "notes": "Please arrange for outdoor seating arrangement"
}
```

**Success Response (201):**
```json
{
  "success": true,
  "message": "Order created successfully",
  "data": {
    "order": {
      "_id": "507f1f77bcf86cd799439020",
      "user": "507f1f77bcf86cd799439011",
      "services": [
        {
          "serviceId": "507f1f77bcf86cd799439011",
          "serviceName": "Premium Wedding Venue",
          "price": 50000,
          "quantity": 1
        },
        {
          "serviceId": "507f1f77bcf86cd799439012",
          "serviceName": "Professional Photography",
          "price": 25000,
          "quantity": 1
        }
      ],
      "totalPrice": 75000,
      "status": "pending",
      "eventDate": "2024-06-15T10:00:00Z",
      "eventType": "Wedding",
      "notes": "Please arrange for outdoor seating arrangement",
      "createdAt": "2024-01-20T14:30:00Z",
      "updatedAt": "2024-01-20T14:30:00Z"
    }
  }
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "Please provide at least one service"
}
```

---

### 7. Get User's Orders
**Endpoint:** `GET /orders`

**Authentication:** Required (JWT Token)

**Description:** Retrieve all orders for authenticated user.

**Headers:**
```
Authorization: Bearer <your_jwt_token>
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `status` (optional): Filter by status (pending, confirmed, completed, cancelled)

**Examples:**
```
GET /orders
GET /orders?page=1&limit=5
GET /orders?status=pending
GET /orders?page=2&status=confirmed
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Orders retrieved successfully",
  "data": {
    "orders": [
      {
        "_id": "507f1f77bcf86cd799439020",
        "user": {
          "_id": "507f1f77bcf86cd799439011",
          "name": "John Doe",
          "email": "customer@example.com"
        },
        "services": [
          {
            "serviceId": {
              "_id": "507f1f77bcf86cd799439011",
              "serviceName": "Premium Wedding Venue",
              "description": "Luxurious indoor venue",
              "price": 50000
            },
            "serviceName": "Premium Wedding Venue",
            "price": 50000,
            "quantity": 1
          }
        ],
        "totalPrice": 50000,
        "status": "pending",
        "eventDate": "2024-06-15T10:00:00Z",
        "eventType": "Wedding",
        "createdAt": "2024-01-20T14:30:00Z"
      }
    ],
    "pagination": {
      "totalOrders": 3,
      "currentPage": 1,
      "totalPages": 1,
      "hasNextPage": false,
      "hasPreviousPage": false
    }
  }
}
```

---

### 8. Get Specific Order
**Endpoint:** `GET /orders/:id`

**Authentication:** Required (JWT Token)

**Description:** Retrieve details for a specific order (user can only access their own orders).

**Headers:**
```
Authorization: Bearer <your_jwt_token>
```

**Parameters:**
- `id` (required): MongoDB ObjectId of the order

**Example:**
```
GET /orders/507f1f77bcf86cd799439020
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Order details retrieved successfully",
  "data": {
    "order": {
      "_id": "507f1f77bcf86cd799439020",
      "user": {
        "_id": "507f1f77bcf86cd799439011",
        "name": "John Doe",
        "email": "customer@example.com"
      },
      "services": [
        {
          "serviceId": {
            "_id": "507f1f77bcf86cd799439011",
            "serviceName": "Premium Wedding Venue"
          },
          "serviceName": "Premium Wedding Venue",
          "price": 50000,
          "quantity": 1
        }
      ],
      "totalPrice": 50000,
      "status": "pending",
      "eventDate": "2024-06-15T10:00:00Z",
      "eventType": "Wedding",
      "notes": "Please arrange for outdoor seating",
      "createdAt": "2024-01-20T14:30:00Z"
    }
  }
}
```

**Error Response (403):**
```json
{
  "success": false,
  "message": "You do not have permission to access this order"
}
```

---

## Admin-Only Endpoints

### 9. Get All Orders (Admin)
**Endpoint:** `GET /admin/orders`

**Authentication:** Required (JWT Token with admin role)

**Description:** Retrieve all orders in the system (admin only).

**Headers:**
```
Authorization: Bearer <admin_jwt_token>
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `status` (optional): Filter by status

**Success Response (200):**
```json
{
  "success": true,
  "message": "All orders retrieved successfully",
  "data": {
    "orders": [
      {
        "_id": "507f1f77bcf86cd799439020",
        "user": {
          "_id": "507f1f77bcf86cd799439011",
          "name": "John Doe",
          "email": "customer@example.com"
        },
        "totalPrice": 50000,
        "status": "pending",
        "eventDate": "2024-06-15T10:00:00Z",
        "eventType": "Wedding",
        "createdAt": "2024-01-20T14:30:00Z"
      }
    ],
    "pagination": {
      "totalOrders": 15,
      "currentPage": 1,
      "totalPages": 2,
      "hasNextPage": true,
      "hasPreviousPage": false
    }
  }
}
```

**Error Response (403):**
```json
{
  "success": false,
  "message": "Forbidden: Admin access required"
}
```

---

### 10. Update Order Status (Admin)
**Endpoint:** `PATCH /admin/orders/:id/status`

**Authentication:** Required (JWT Token with admin role)

**Description:** Update the status of an order (admin only).

**Headers:**
```
Authorization: Bearer <admin_jwt_token>
```

**Parameters:**
- `id` (required): MongoDB ObjectId of the order

**Request Body:**
```json
{
  "status": "confirmed"
}
```

**Valid Status Values:**
- `pending`
- `confirmed`
- `completed`
- `cancelled`

**Success Response (200):**
```json
{
  "success": true,
  "message": "Order status updated successfully",
  "data": {
    "order": {
      "_id": "507f1f77bcf86cd799439020",
      "status": "confirmed",
      "user": {
        "_id": "507f1f77bcf86cd799439011",
        "name": "John Doe",
        "email": "customer@example.com"
      },
      "totalPrice": 50000,
      "eventDate": "2024-06-15T10:00:00Z",
      "eventType": "Wedding",
      "updatedAt": "2024-01-20T15:45:00Z"
    }
  }
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "Invalid status value"
}
```

---

## Error Handling

All API endpoints return appropriate HTTP status codes:

| Status Code | Meaning |
|-------------|---------|
| 200 | OK - Request successful |
| 201 | Created - Resource created successfully |
| 400 | Bad Request - Invalid input or missing required fields |
| 401 | Unauthorized - Missing or invalid authentication token |
| 403 | Forbidden - Insufficient permissions or token validation failed |
| 404 | Not Found - Resource not found |
| 409 | Conflict - Resource already exists (e.g., email taken) |
| 500 | Internal Server Error - Server-side error |

---

## Example Usage

### JavaScript/Fetch API

**Login and Get Token:**
```javascript
const loginResponse = await fetch('http://localhost:3000/api/v1/auth/login', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    email: 'customer@example.com',
    password: 'password123'
  })
});

const loginData = await loginResponse.json();
const token = loginData.data.token;
```

**Get User Profile (Protected):**
```javascript
const profileResponse = await fetch('http://localhost:3000/api/v1/user/profile', {
  method: 'GET',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
});

const profileData = await profileResponse.json();
console.log(profileData.data.user);
```

**Get All Products:**
```javascript
const productsResponse = await fetch('http://localhost:3000/api/v1/products?page=1&category=Wedding', {
  method: 'GET',
  headers: {
    'Content-Type': 'application/json'
  }
});

const productsData = await productsResponse.json();
console.log(productsData.data.products);
```

**Create Order (Protected):**
```javascript
const orderResponse = await fetch('http://localhost:3000/api/v1/orders', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    services: [
      {
        serviceId: '507f1f77bcf86cd799439011',
        serviceName: 'Premium Wedding Venue',
        price: 50000,
        quantity: 1
      }
    ],
    totalPrice: 50000,
    eventDate: '2024-06-15T10:00:00Z',
    eventType: 'Wedding',
    notes: 'Special requests here'
  })
});

const orderData = await orderResponse.json();
console.log(orderData.data.order);
```

---

## Security Considerations

1. **HTTPS in Production:** Always use HTTPS in production to protect tokens during transmission.
2. **Token Storage:** Store JWT tokens securely (e.g., httpOnly cookies, secure storage in mobile apps).
3. **Token Expiration:** Tokens expire after 24 hours. Implement refresh token mechanism for long-lived sessions.
4. **Environment Variables:** Keep `JWT_SECRET` secure and never commit it to version control.
5. **CORS:** Configure CORS appropriately for your frontend domains.
6. **Input Validation:** Always validate user input on the server side.
7. **Rate Limiting:** Implement rate limiting to prevent brute-force attacks (recommended for production).

---

## Database Seeding

To populate the database with sample services:

```bash
npm run seed
```

To seed sample users:

```bash
npm run seed:users
```

---

## Support

For issues or questions about the API, please refer to the project documentation or contact the development team.
