// ==========================================
// ADMIN ROUTES
// ==========================================
// This route handles admin operations:
// - Dashboard: View all services
// - Create: Add new services with image upload
// - Update: Edit existing services
// - Delete: Remove services with confirmation

const express = require('express');
const Service = require('../models/Service');
const multer = require('multer');
const path = require('path');
const router = express.Router();

// ==========================================
// MULTER CONFIGURATION FOR IMAGE UPLOADS
// ==========================================

// Set storage destination and filename
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads/');
  },
  filename: function (req, file, cb) {
    // Create unique filename: timestamp-originalname
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

// Filter to accept only image files
const fileFilter = (req, file, cb) => {
  // Allowed file types
  const allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
  
  if (allowedMimes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Only image files are allowed (JPG, PNG, GIF, WebP)'), false);
  }
};

// Multer instance with configuration
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// ==========================================
// ADMIN DASHBOARD - GET ALL SERVICES
// ==========================================
router.get('/', async (req, res) => {
  try {
    // Fetch all services from database sorted by creation date (newest first)
    const services = await Service.find().sort({ createdAt: -1 });
    
    // Count total services
    const totalServices = services.length;
    
    // Calculate basic statistics
    const averagePrice = services.length > 0 
      ? (services.reduce((sum, s) => sum + s.price, 0) / services.length).toFixed(2)
      : 0;
    
    const categories = await Service.distinct('category');
    
    // Render admin dashboard
    res.render('admin-layout', {
      content: 'admin/dashboard',
      title: 'Dashboard',
      services: services,
      totalServices: totalServices,
      averagePrice: averagePrice,
      totalCategories: categories.length
    });
  } catch (error) {
    console.error('Error loading admin dashboard:', error);
    res.status(500).render('404', {
      message: 'Error loading admin dashboard'
    });
  }
});

// ==========================================
// ADD SERVICE PAGE - DISPLAY FORM
// ==========================================
router.get('/add', (req, res) => {
  try {
    res.render('admin-layout', {
      content: 'admin/add-service',
      title: 'Add New Service',
      categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
    });
  } catch (error) {
    console.error('Error loading add service form:', error);
    res.status(500).render('404', {
      message: 'Error loading form'
    });
  }
});

// ==========================================
// CREATE NEW SERVICE - HANDLE FORM SUBMISSION
// ==========================================
router.post('/add', upload.single('image'), async (req, res) => {
  try {
    // Validate required fields
    const { serviceName, description, price, category, rating, availability } = req.body;
    
    if (!serviceName || !description || !price || !category) {
      return res.status(400).render('admin-layout', {
        content: 'admin/add-service',
        title: 'Add New Service',
        error: 'Please fill in all required fields',
        categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
      });
    }

    // Validate price is a positive number
    if (isNaN(price) || parseFloat(price) <= 0) {
      return res.status(400).render('admin-layout', {
        content: 'admin/add-service',
        title: 'Add New Service',
        error: 'Price must be a positive number',
        categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
      });
    }

    // Validate rating
    const ratingValue = parseFloat(rating) || 4.5;
    if (ratingValue < 0 || ratingValue > 5) {
      return res.status(400).render('admin-layout', {
        content: 'admin/add-service',
        title: 'Add New Service',
        error: 'Rating must be between 0 and 5',
        categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
      });
    }

    // Set image path from uploaded file or use default
    let imagePath = '/images/default-service.jpg';
    if (req.file) {
      imagePath = '/uploads/' + req.file.filename;
    }

    // Create new service document
    const newService = new Service({
      serviceName: serviceName.trim(),
      description: description.trim(),
      price: parseFloat(price),
      category: category,
      rating: ratingValue,
      availability: availability === 'true' || availability === true,
      image: imagePath
    });

    // Save to database
    await newService.save();

    console.log('✅ New service added:', newService._id);
    res.redirect('/admin?success=Service added successfully');
  } catch (error) {
    console.error('Error adding service:', error);
    res.status(500).render('admin-layout', {
      content: 'admin/add-service',
      title: 'Add New Service',
      error: 'Error adding service. Please try again.',
      categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
    });
  }
});

// ==========================================
// EDIT SERVICE PAGE - DISPLAY FORM WITH EXISTING DATA
// ==========================================
router.get('/edit/:id', async (req, res) => {
  try {
    // Find service by ID
    const service = await Service.findById(req.params.id);
    
    if (!service) {
      return res.status(404).render('404', {
        message: 'Service not found'
      });
    }

    res.render('admin-layout', {
      content: 'admin/edit-service',
      title: 'Edit Service',
      service: service,
      categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
    });
  } catch (error) {
    console.error('Error loading edit service form:', error);
    res.status(500).render('404', {
      message: 'Error loading form'
    });
  }
});

// ==========================================
// UPDATE SERVICE - HANDLE FORM SUBMISSION
// ==========================================
router.post('/edit/:id', upload.single('image'), async (req, res) => {
  try {
    // Validate required fields
    const { serviceName, description, price, category, rating, availability } = req.body;
    
    if (!serviceName || !description || !price || !category) {
      const service = await Service.findById(req.params.id);
      return res.status(400).render('admin/edit-service', {
        service: service,
        error: 'Please fill in all required fields',
        categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
      });
    }

    // Validate price is a positive number
    if (isNaN(price) || parseFloat(price) <= 0) {
      const service = await Service.findById(req.params.id);
      return res.status(400).render('admin/edit-service', {
        service: service,
        error: 'Price must be a positive number',
        categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
      });
    }

    // Find service by ID
    const service = await Service.findById(req.params.id);
    
    if (!service) {
      return res.status(404).render('404', {
        message: 'Service not found'
      });
    }

    // Update service fields
    service.serviceName = serviceName.trim();
    service.description = description.trim();
    service.price = parseFloat(price);
    service.category = category;
    service.rating = parseFloat(rating) || 4.5;
    service.availability = availability === 'true' || availability === true;

    // Update image if a new one was uploaded
    if (req.file) {
      service.image = '/uploads/' + req.file.filename;
    }

    // Save updated service
    await service.save();

    console.log('✅ Service updated:', service._id);
    res.redirect('/admin?success=Service updated successfully');
  } catch (error) {
    console.error('Error updating service:', error);
    const service = await Service.findById(req.params.id);
    res.status(500).render('admin/edit-service', {
      service: service,
      error: 'Error updating service. Please try again.',
      categories: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']
    });
  }
});

// ==========================================
// DELETE SERVICE
// ==========================================
router.post('/delete/:id', async (req, res) => {
  try {
    // Find and delete service by ID
    const service = await Service.findByIdAndDelete(req.params.id);
    
    if (!service) {
      return res.status(404).json({ success: false, message: 'Service not found' });
    }

    console.log('✅ Service deleted:', req.params.id);
    res.json({ success: true, message: 'Service deleted successfully' });
  } catch (error) {
    console.error('Error deleting service:', error);
    res.status(500).json({ success: false, message: 'Error deleting service' });
  }
});

module.exports = router;
