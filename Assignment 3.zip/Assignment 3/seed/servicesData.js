// ==========================================
// SEED DATA FOR SERVICES
// ==========================================
// This file contains sample data for testing the services page
// Run this with: node seed/servicesData.js

const mongoose = require('mongoose');
const Service = require('../models/Service');

// MongoDB Connection String
// Change this to your MongoDB URI (local or Atlas)
const MONGODB_URI = 'mongodb://localhost:27017/majestic-marquee';

// Sample Services Data
const servicesData = [
  // Wedding Services
  {
    serviceName: 'Royal Wedding Setup',
    description: 'Complete wedding setup with elegant decoration, lighting, and seating arrangements',
    price: 50000,
    category: 'Wedding',
    rating: 4.8,
    availability: true,
    image: '/images/wedding-setup.jpg'
  },
  {
    serviceName: 'Luxury Bridal Package',
    description: 'Premium bridal services including makeup, styling, and photography',
    price: 35000,
    category: 'Wedding',
    rating: 4.9,
    availability: true,
    image: '/images/bridal-package.jpg'
  },
  {
    serviceName: 'Floral Stage Design',
    description: 'Beautiful floral arrangements for stage with fresh flowers',
    price: 25000,
    category: 'Wedding',
    rating: 4.7,
    availability: true,
    image: '/images/floral-stage.jpg'
  },
  {
    serviceName: 'VIP Catering Service',
    description: 'Multi-cuisine catering with professional staff and service',
    price: 45000,
    category: 'Wedding',
    rating: 4.6,
    availability: true,
    image: '/images/catering-service.jpg'
  },
  {
    serviceName: 'Outdoor Lighting Theme',
    description: 'Ambient outdoor lighting with LED decorations',
    price: 20000,
    category: 'Wedding',
    rating: 4.5,
    availability: true,
    image: '/images/outdoor-lighting.jpg'
  },
  {
    serviceName: 'Wedding Videography',
    description: 'Professional 4K video coverage with editing and cinematic effects',
    price: 40000,
    category: 'Wedding',
    rating: 4.8,
    availability: true,
    image: '/images/videography.jpg'
  },
  {
    serviceName: 'Marquee Tent Rental',
    description: 'Premium marquee tent with weather protection and elegant interior',
    price: 60000,
    category: 'Wedding',
    rating: 4.7,
    availability: true,
    image: '/images/marquee-tent.jpg'
  },
  
  // Mehndi Services
  {
    serviceName: 'Luxury Mehndi Decoration',
    description: 'Traditional mehndi setup with colorful decorations and traditional seating',
    price: 18000,
    category: 'Mehndi',
    rating: 4.6,
    availability: true,
    image: '/images/mehndi-decoration.jpg'
  },
  {
    serviceName: 'Professional Mehndi Artists',
    description: 'Experienced mehndi artists for bridal and guest application',
    price: 15000,
    category: 'Mehndi',
    rating: 4.8,
    availability: true,
    image: '/images/mehndi-artists.jpg'
  },
  {
    serviceName: 'Colorful Props & Backdrops',
    description: 'Colorful themed backdrops and photo props for mehndi event',
    price: 12000,
    category: 'Mehndi',
    rating: 4.5,
    availability: true,
    image: '/images/mehndi-props.jpg'
  },
  {
    serviceName: 'Mehndi Music & Entertainment',
    description: 'Live music and entertainment with DJ services',
    price: 10000,
    category: 'Mehndi',
    rating: 4.4,
    availability: true,
    image: '/images/entertainment.jpg'
  },
  
  // Barat Services
  {
    serviceName: 'Grand Barat Setup',
    description: 'Complete barat arrangement with traditional decorations',
    price: 30000,
    category: 'Barat',
    rating: 4.7,
    availability: true,
    image: '/images/barat-setup.jpg'
  },
  {
    serviceName: 'Horse & Baraat Decoration',
    description: 'Decorated horses and baraat procession setup',
    price: 25000,
    category: 'Barat',
    rating: 4.6,
    availability: true,
    image: '/images/horse-barat.jpg'
  },
  {
    serviceName: 'Baraat Music Band',
    description: 'Professional music band for baraat procession',
    price: 12000,
    category: 'Barat',
    rating: 4.5,
    availability: true,
    image: '/images/music-band.jpg'
  },
  {
    serviceName: 'Barat Tent & Seating',
    description: 'Elegant tent and comfortable seating for baraat',
    price: 20000,
    category: 'Barat',
    rating: 4.5,
    availability: true,
    image: '/images/barat-tent.jpg'
  },
  
  // Walima Services
  {
    serviceName: 'Premium Walima Package',
    description: 'Complete walima setup with catering and decoration',
    price: 55000,
    category: 'Walima',
    rating: 4.8,
    availability: true,
    image: '/images/walima-package.jpg'
  },
  {
    serviceName: 'Walima Dining Setup',
    description: 'Elegant dining arrangement with table setup and centerpieces',
    price: 28000,
    category: 'Walima',
    rating: 4.6,
    availability: true,
    image: '/images/walima-dining.jpg'
  },
  {
    serviceName: 'Groom Reception Area',
    description: 'Special seating and decoration for groom reception',
    price: 15000,
    category: 'Walima',
    rating: 4.5,
    availability: true,
    image: '/images/groom-reception.jpg'
  },
  {
    serviceName: 'Walima Photography',
    description: 'Professional photography with editing and albums',
    price: 18000,
    category: 'Walima',
    rating: 4.7,
    availability: true,
    image: '/images/walima-photo.jpg'
  },
  
  // Birthday Events
  {
    serviceName: 'Kids Birthday Setup',
    description: 'Fun and colorful setup for children\'s birthday parties',
    price: 12000,
    category: 'Birthday Events',
    rating: 4.5,
    availability: true,
    image: '/images/birthday-kids.jpg'
  },
  {
    serviceName: 'Elegant Adult Birthday',
    description: 'Sophisticated decoration and setup for adult birthday parties',
    price: 22000,
    category: 'Birthday Events',
    rating: 4.6,
    availability: true,
    image: '/images/birthday-adult.jpg'
  },
  {
    serviceName: 'Birthday Catering Service',
    description: 'Customized menu and catering for birthday celebrations',
    price: 18000,
    category: 'Birthday Events',
    rating: 4.5,
    availability: true,
    image: '/images/birthday-catering.jpg'
  },
  
  // Corporate Events
  {
    serviceName: 'Corporate Conference Setup',
    description: 'Professional setup for conferences and business meetings',
    price: 35000,
    category: 'Corporate Events',
    rating: 4.7,
    availability: true,
    image: '/images/corporate-conference.jpg'
  },
  {
    serviceName: 'Corporate Gala Dinner',
    description: 'Elegant gala dinner setup with professional service',
    price: 40000,
    category: 'Corporate Events',
    rating: 4.8,
    availability: true,
    image: '/images/corporate-gala.jpg'
  },
  {
    serviceName: 'Business Event Catering',
    description: 'Professional catering for business events and seminars',
    price: 25000,
    category: 'Corporate Events',
    rating: 4.6,
    availability: true,
    image: '/images/corporate-catering.jpg'
  },
  {
    serviceName: 'AV & Sound System Rental',
    description: 'Professional audio-visual equipment and sound systems',
    price: 15000,
    category: 'Corporate Events',
    rating: 4.7,
    availability: true,
    image: '/images/av-system.jpg'
  }
];

// Function to seed the database
async function seedDatabase() {
  try {
    // Connect to MongoDB
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ Connected to MongoDB');

    // Clear existing services
    await Service.deleteMany({});
    console.log('🗑️  Cleared existing services');

    // Insert new services
    const insertedServices = await Service.insertMany(servicesData);
    console.log(`✅ Inserted ${insertedServices.length} services`);

    console.log('\n📊 Services Summary:');
    const categorySummary = await Service.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } }
    ]);
    categorySummary.forEach(cat => {
      console.log(`   ${cat._id}: ${cat.count} services`);
    });

    // Disconnect from database
    await mongoose.disconnect();
    console.log('\n✅ Database seeding completed successfully!');
  } catch (error) {
    console.error('❌ Error seeding database:', error.message);
    process.exit(1);
  }
}

// Run the seeding function
seedDatabase();
