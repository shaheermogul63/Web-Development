# Assignment 3 - Dynamic Event Services Catalog Setup Guide

## 📋 Overview

This guide walks you through setting up and running the **Dynamic Event Services Catalog** with MongoDB integration for the Majestic Marquee wedding venue website.

---

## 🛠️ Prerequisites

Before starting, ensure you have:

1. **Node.js** (v14 or higher) - [Download](https://nodejs.org/)
2. **MongoDB Community Edition** - [Download](https://www.mongodb.com/try/download/community)
   - OR MongoDB Atlas (Cloud) - [Sign up free](https://www.mongodb.com/cloud/atlas)
3. **Git** (optional but recommended) - [Download](https://git-scm.com/)

---

## 🚀 Quick Start

### Step 1: Install Dependencies

Open PowerShell/Terminal in your project folder and run:

```bash
npm install
```

This will install:
- Express.js (web framework)
- EJS (templating engine)
- Mongoose (MongoDB driver)
- Nodemon (development tool)

### Step 2: Set Up MongoDB

#### Option A: Local MongoDB (Recommended for Development)

1. Install MongoDB Community Edition from [mongodb.com](https://www.mongodb.com/try/download/community)
2. Start the MongoDB server:
   - **Windows:** `mongod` (usually starts automatically)
   - **Mac:** `brew services start mongodb-community`
   - **Linux:** `sudo systemctl start mongod`

#### Option B: MongoDB Atlas (Cloud)

1. Create a free account at [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)
2. Create a new cluster
3. Get your connection string (looks like):
   ```
   mongodb+srv://username:password@cluster.mongodb.net/majestic-marquee
   ```
4. Create a `.env` file in your project root:
   ```
   MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/majestic-marquee
   ```

### Step 3: Seed the Database

Populate the database with 25 sample services:

```bash
npm run seed
```

You should see:
```
✅ Connected to MongoDB
🗑️  Cleared existing services
✅ Inserted 25 services

📊 Services Summary:
   Wedding: 7 services
   Mehndi: 4 services
   Barat: 4 services
   Walima: 4 services
   Birthday Events: 3 services
   Corporate Events: 3 services

✅ Database seeding completed successfully!
```

### Step 4: Start the Server

**Development mode** (with auto-restart):
```bash
npm run dev
```

**Production mode**:
```bash
npm start
```

You should see:
```
✅ MongoDB connected successfully
🚀 Server is running on http://localhost:3000

📄 Routes:
   Homepage: http://localhost:3000/
   Services: http://localhost:3000/services
   Contact: http://localhost:3000/contact-us

📚 Services Features:
   • Pagination: http://localhost:3000/services?page=1
   • Filter by Category: http://localhost:3000/services?category=Wedding
   • Search: http://localhost:3000/services?search=Mehndi
   • Combine: http://localhost:3000/services?page=1&category=Wedding&search=Luxury
```

### Step 5: Access the Application

Open your browser and go to:

- **Homepage:** http://localhost:3000/
- **Services Page:** http://localhost:3000/services
- **Services with Pagination:** http://localhost:3000/services?page=1
- **Filter by Category:** http://localhost:3000/services?category=Wedding
- **Search Services:** http://localhost:3000/services?search=Mehndi

---

## 📚 Project Structure

```
Assignment 3/
│
├── models/
│   └── Service.js                 ← Mongoose schema definition
│
├── routes/
│   └── services.js                ← Services endpoints (GET /services)
│
├── seed/
│   └── servicesData.js            ← Sample data (run with 'npm run seed')
│
├── views/
│   ├── homepage.ejs               ← Main landing page
│   ├── services.ejs               ← Services catalog page ✨ NEW
│   ├── 404.ejs                    ← Error page
│   └── partials/
│
├── public/
│   ├── css/
│   │   ├── style.css              ← Main styling
│   │   └── services.css           ← Services page styling ✨ NEW
│   ├── js/
│   │   └── app.js                 ← Frontend functionality
│   └── images/
│
├── server.js                      ← Main Express application
├── package.json                   ← Dependencies & scripts
└── ASSIGNMENT_3_SETUP.md          ← This file
```

---

## 🌐 Features Implemented

### ✅ Core Features

1. **Dynamic Service Catalog**
   - Display services from MongoDB database
   - Service cards with image, name, price, rating, availability

2. **Server-Side Pagination**
   - Display 8 services per page
   - Previous/Next buttons
   - Page number navigation
   - Query parameter: `?page=1`

3. **Category Filtering**
   - Filter by 6 categories:
     - Wedding
     - Mehndi
     - Barat
     - Walima
     - Birthday Events
     - Corporate Events
   - Query parameter: `?category=Wedding`

4. **Search Functionality**
   - Search by service name, category, or description
   - Case-insensitive search
   - Query parameter: `?search=Luxury`

5. **Responsive Design**
   - Desktop (1200px+)
   - Tablet (768px - 1199px)
   - Mobile (480px - 767px)
   - Extra small (under 360px)
   - No CSS frameworks - Plain CSS with flexbox/grid

6. **Service Card Details**
   - Service image with hover effect
   - Availability badge (Available/Unavailable)
   - Category tag (clickable for filtering)
   - Service name and description
   - Star rating (0-5 stars)
   - Price in PKR
   - "Book Now" button

---

## 🔍 API Endpoints

### Services Route

```
GET /services
├── Query Parameters:
│   ├── page: number (default: 1)          - Page number for pagination
│   ├── category: string                   - Filter by category
│   └── search: string                     - Search query
└── Examples:
    ├── /services                          - First page, all services
    ├── /services?page=2                   - Second page
    ├── /services?category=Wedding         - Wedding services only
    ├── /services?search=Luxury            - Search results
    └── /services?page=1&category=Wedding&search=Luxury  - Combined filters
```

---

## 💾 MongoDB Schema

### Service Model

```javascript
{
  serviceName: String (required),
  description: String (required),
  price: Number (required),
  category: String (enum: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events']),
  rating: Number (0-5, default: 4.5),
  availability: Boolean (default: true),
  image: String (URL path, default: '/images/default-service.jpg'),
  createdAt: Date (default: current timestamp)
}
```

---

## 🧪 Testing the Features

### Test Pagination

1. Go to: http://localhost:3000/services
2. Click "Next" button or go to page 2
3. Verify you see different services

### Test Category Filter

1. Click "Wedding" button
2. Verify only wedding services appear
3. Click another category and check
4. Combined with pagination: http://localhost:3000/services?page=1&category=Mehndi

### Test Search

1. Type "Luxury" in search box and click Search
2. Verify matching services appear
3. Try searching for "Wedding", "Catering", etc.

### Test Responsive Design

1. Open Developer Tools (F12)
2. Toggle device toolbar for mobile view
3. Verify layout adapts properly
4. Test on different screen sizes

---

## 🐛 Troubleshooting

### MongoDB Connection Error

**Problem:** "MongoDB connection error: connection refused"

**Solution:**
- Ensure MongoDB is running (`mongod` command)
- Check if MongoDB is installed: `mongod --version`
- For Atlas, verify your connection string in `.env` file

### Seed Script Error

**Problem:** "Seed data insertion failed"

**Solution:**
```bash
# Delete existing data and try again
npm run seed

# If that fails, connect to MongoDB directly:
mongo  # Then manually clear database
```

### Port Already in Use

**Problem:** "Port 3000 already in use"

**Solution:**
- Change PORT in `server.js`:
  ```javascript
  const PORT = 3001; // Change to different port
  ```
- Or kill the process using port 3000

### Dependencies Not Installing

**Problem:** npm install fails

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Remove node_modules and package-lock.json
rmdir /s node_modules
del package-lock.json

# Reinstall
npm install
```

---

## 📝 Sample Service Data

The seed file includes 25 services across 6 categories:

**Wedding (7 services):**
- Royal Wedding Setup
- Luxury Bridal Package
- Floral Stage Design
- VIP Catering Service
- Outdoor Lighting Theme
- Wedding Videography
- Marquee Tent Rental

**Mehndi (4 services):**
- Luxury Mehndi Decoration
- Professional Mehndi Artists
- Colorful Props & Backdrops
- Mehndi Music & Entertainment

**Barat (4 services):**
- Grand Barat Setup
- Horse & Baraat Decoration
- Baraat Music Band
- Barat Tent & Seating

**Walima (4 services):**
- Premium Walima Package
- Walima Dining Setup
- Groom Reception Area
- Walima Photography

**Birthday Events (3 services):**
- Kids Birthday Setup
- Elegant Adult Birthday
- Birthday Catering Service

**Corporate Events (3 services):**
- Corporate Conference Setup
- Corporate Gala Dinner
- Business Event Catering
- AV & Sound System Rental

---

## 🚀 Deployment

To deploy your application:

1. **Heroku**
   ```bash
   heroku login
   heroku create your-app-name
   git push heroku main
   ```

2. **Vercel** (for frontend only)
   - Services require Node.js backend (use Heroku/Railway/Render)

3. **Railway** (Recommended)
   - Connect GitHub repository
   - Auto-deploys on push

---

## 📞 Support

For issues or questions:

1. Check the troubleshooting section above
2. Review MongoDB documentation: https://docs.mongodb.com/
3. Review Express.js documentation: https://expressjs.com/
4. Review Mongoose documentation: https://mongoosejs.com/

---

## 📋 Checklist

- [ ] Node.js installed
- [ ] MongoDB installed and running
- [ ] Dependencies installed (`npm install`)
- [ ] Database seeded (`npm run seed`)
- [ ] Server running (`npm start` or `npm run dev`)
- [ ] Services page working (http://localhost:3000/services)
- [ ] Pagination working
- [ ] Filtering working
- [ ] Search working
- [ ] Responsive design tested

---

## 🎉 You're All Set!

Your Dynamic Event Services Catalog is now ready to use. Start exploring the services, test pagination, filtering, and search functionality!

**Happy coding! 🚀**
