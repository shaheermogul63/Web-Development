// Services Data - Client-side data store for all services
const servicesData = [
  // Wedding Services
  {
    id: 1,
    serviceName: 'Royal Wedding Setup',
    description: 'Complete wedding setup with elegant decoration, lighting, and seating arrangements',
    price: 50000,
    category: 'Wedding',
    rating: 4.8,
    availability: true,
    image: '/images/wedding-setup.jpg'
  },
  {
    id: 2,
    serviceName: 'Luxury Bridal Package',
    description: 'Premium bridal services including makeup, styling, and photography',
    price: 35000,
    category: 'Wedding',
    rating: 4.9,
    availability: true,
    image: '/images/bridal-package.jpg'
  },
  {
    id: 3,
    serviceName: 'Floral Stage Design',
    description: 'Beautiful floral arrangements for stage with fresh flowers',
    price: 25000,
    category: 'Wedding',
    rating: 4.7,
    availability: true,
    image: '/images/floral-stage.jpg'
  },
  {
    id: 4,
    serviceName: 'VIP Catering Service',
    description: 'Multi-cuisine catering with professional staff and service',
    price: 45000,
    category: 'Wedding',
    rating: 4.6,
    availability: true,
    image: '/images/catering-service.jpg'
  },
  {
    id: 5,
    serviceName: 'Outdoor Lighting Theme',
    description: 'Ambient outdoor lighting with LED decorations',
    price: 20000,
    category: 'Wedding',
    rating: 4.5,
    availability: true,
    image: '/images/outdoor-lighting.jpg'
  },
  {
    id: 6,
    serviceName: 'Wedding Videography',
    description: 'Professional 4K video coverage with editing and cinematic effects',
    price: 40000,
    category: 'Wedding',
    rating: 4.8,
    availability: true,
    image: '/images/videography.jpg'
  },
  {
    id: 7,
    serviceName: 'Marquee Tent Rental',
    description: 'Premium marquee tent with weather protection and elegant interior',
    price: 60000,
    category: 'Wedding',
    rating: 4.7,
    availability: true,
    image: '/images/marquee-tent.jpg'
  },
  
  // Mehndi Services
  {
    id: 8,
    serviceName: 'Luxury Mehndi Decoration',
    description: 'Traditional mehndi setup with colorful decorations and traditional seating',
    price: 18000,
    category: 'Mehndi',
    rating: 4.6,
    availability: true,
    image: '/images/mehndi-decoration.jpg'
  },
  {
    id: 9,
    serviceName: 'Professional Mehndi Artists',
    description: 'Experienced mehndi artists for bridal and guest application',
    price: 15000,
    category: 'Mehndi',
    rating: 4.8,
    availability: true,
    image: '/images/mehndi-artists.jpg'
  },
  {
    id: 10,
    serviceName: 'Colorful Props & Backdrops',
    description: 'Colorful themed backdrops and photo props for mehndi event',
    price: 12000,
    category: 'Mehndi',
    rating: 4.5,
    availability: true,
    image: '/images/mehndi-props.jpg'
  },
  {
    id: 11,
    serviceName: 'Mehndi Music & Entertainment',
    description: 'Live music and entertainment with DJ services',
    price: 10000,
    category: 'Mehndi',
    rating: 4.4,
    availability: true,
    image: '/images/entertainment.jpg'
  },
  
  // Barat Services
  {
    id: 12,
    serviceName: 'Grand Barat Setup',
    description: 'Complete barat arrangement with traditional decorations',
    price: 30000,
    category: 'Barat',
    rating: 4.7,
    availability: true,
    image: '/images/barat-setup.jpg'
  },
  {
    id: 13,
    serviceName: 'Horse & Baraat Decoration',
    description: 'Decorated horses and baraat procession setup',
    price: 25000,
    category: 'Barat',
    rating: 4.6,
    availability: true,
    image: '/images/horse-barat.jpg'
  },
  {
    id: 14,
    serviceName: 'Baraat Music Band',
    description: 'Professional music band for baraat procession',
    price: 12000,
    category: 'Barat',
    rating: 4.5,
    availability: true,
    image: '/images/music-band.jpg'
  },
  {
    id: 15,
    serviceName: 'Barat Tent & Seating',
    description: 'Elegant tent and comfortable seating for baraat',
    price: 20000,
    category: 'Barat',
    rating: 4.5,
    availability: true,
    image: '/images/barat-tent.jpg'
  },
  
  // Walima Services
  {
    id: 16,
    serviceName: 'Premium Walima Package',
    description: 'Complete walima setup with catering and decoration',
    price: 55000,
    category: 'Walima',
    rating: 4.8,
    availability: true,
    image: '/images/walima-package.jpg'
  },
  {
    id: 17,
    serviceName: 'Walima Dining Setup',
    description: 'Elegant dining arrangement with table setup and centerpieces',
    price: 28000,
    category: 'Walima',
    rating: 4.6,
    availability: true,
    image: '/images/walima-dining.jpg'
  },
  {
    id: 18,
    serviceName: 'Groom Reception Area',
    description: 'Special seating and decoration for groom reception',
    price: 15000,
    category: 'Walima',
    rating: 4.5,
    availability: true,
    image: '/images/groom-reception.jpg'
  },
  {
    id: 19,
    serviceName: 'Walima Photography',
    description: 'Professional photography with editing and albums',
    price: 18000,
    category: 'Walima',
    rating: 4.7,
    availability: true,
    image: '/images/walima-photo.jpg'
  },
  
  // Birthday Events
  {
    id: 20,
    serviceName: 'Kids Birthday Setup',
    description: 'Fun and colorful setup for children\'s birthday parties',
    price: 12000,
    category: 'Birthday Events',
    rating: 4.5,
    availability: true,
    image: '/images/birthday-kids.jpg'
  },
  {
    id: 21,
    serviceName: 'Elegant Adult Birthday',
    description: 'Sophisticated decoration and setup for adult birthday parties',
    price: 22000,
    category: 'Birthday Events',
    rating: 4.6,
    availability: true,
    image: '/images/birthday-adult.jpg'
  },
  {
    id: 22,
    serviceName: 'Birthday Catering Service',
    description: 'Customized menu and catering for birthday celebrations',
    price: 18000,
    category: 'Birthday Events',
    rating: 4.5,
    availability: true,
    image: '/images/birthday-catering.jpg'
  },
  
  // Corporate Events
  {
    id: 23,
    serviceName: 'Corporate Conference Setup',
    description: 'Professional setup for conferences and business meetings',
    price: 35000,
    category: 'Corporate Events',
    rating: 4.7,
    availability: true,
    image: '/images/corporate-conference.jpg'
  },
  {
    id: 24,
    serviceName: 'Corporate Gala Dinner',
    description: 'Elegant gala dinner setup with professional service',
    price: 40000,
    category: 'Corporate Events',
    rating: 4.8,
    availability: true,
    image: '/images/corporate-gala.jpg'
  },
  {
    id: 25,
    serviceName: 'Business Event Catering',
    description: 'Professional catering for business events and seminars',
    price: 25000,
    category: 'Corporate Events',
    rating: 4.6,
    availability: true,
    image: '/images/corporate-catering.jpg'
  }
];

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = servicesData;
}
