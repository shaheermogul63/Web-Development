# On-Sale Services Implementation - Complete Guide

## ✅ Implementation Summary

This document outlines all the changes made to implement the On-Sale Services page with client-side jQuery pagination.

---

## 1. Database Schema Update

### File: `models/Service.js`
**Change:** Added `isOnSale` field to the Service schema

```javascript
isOnSale: {
  type: Boolean,
  required: true,
  default: false
}
```

**Purpose:** Marks services that are currently on sale, allowing queries to filter promotional items.

---

## 2. Server-Side Route Implementation

### File: `routes/services.js`
**New Route:** `GET /services/onsale-services`

**Route Details:**
- **Path:** `/onsale-services` (within the services router, full path: `/services/onsale-services`)
- **Method:** GET
- **Query:** Finds all services where `isOnSale: true`
- **Sorting:** Orders by `createdAt` descending (newest first)
- **Rendering:** Passes ALL matching services to `onsale.ejs` template

**Code:**
```javascript
router.get('/onsale-services', async (req, res) => {
  try {
    const onSaleServices = await Service.find({ isOnSale: true })
      .sort({ createdAt: -1 });

    res.render('onsale', {
      services: onSaleServices,
      totalServices: onSaleServices.length
    });
  } catch (error) {
    console.error('Error fetching on-sale services:', error);
    res.status(500).render('404', {
      message: 'Error loading on-sale services'
    });
  }
});
```

---

## 3. EJS Template Implementation

### File: `views/onsale.ejs`
**Features:**
- Renders all on-sale services in a responsive grid layout
- Each service card has the class `onsale-item` for jQuery targeting
- Initially hides all items (jQuery manages visibility)
- Includes pagination controls with Previous/Next buttons
- Displays page indicator (e.g., "Page 1 of 5")

**Key HTML Elements:**
```html
<!-- Product container -->
<div class="services-grid" id="product-list">
  <!-- Each service is a card with class "onsale-item" -->
  <div class="service-card onsale-item" style="display: none;" data-index="0">
    <!-- Service details -->
  </div>
</div>

<!-- Pagination controls -->
<div class="pagination" id="pagination-controls">
  <button id="prev-btn">‹ Previous</button>
  <span id="page-indicator">Page 1 of X</span>
  <button id="next-btn">Next ›</button>
</div>
```

---

## 4. Client-Side Pagination Logic (jQuery)

### Location: `views/onsale.ejs` (within `<script>` tag)

**Variables:**
- `itemsPerPage = 10` - Fixed number of items per page
- `currentPage = 1` - Current page index (starts at 1)
- `allItems = $('.onsale-item')` - All service cards
- `totalPages = Math.ceil(totalItems / itemsPerPage)` - Total number of pages

**Functions:**

#### `displayPage(pageNum)`
- Hides all product cards
- Calculates start and end indices for the page
- Shows only the items within the range
- Updates the page indicator text
- Updates button states
- Scrolls to top of product list

**Algorithm:**
```
startIndex = (pageNum - 1) * 10
endIndex = startIndex + 10
Show items[startIndex...endIndex-1]
```

#### `updateButtonStates(pageNum)`
- Disables Previous button if on first page
- Disables Next button if on last page
- Updates button opacity for visual feedback

**Event Handlers:**
- **Previous Button (`#prev-btn`)**: Decrements `currentPage` if > 1, calls `displayPage()`
- **Next Button (`#next-btn`)**: Increments `currentPage` if < totalPages, calls `displayPage()`

**Initialization:**
- On DOM ready, displays the first page (10 items)
- Calculates total pages from total items
- Sets up event listeners

---

## 5. Seed Data Updates

### File: `seed/servicesData.js`
**Change:** Added `isOnSale` field to all services

**Sample Data:**
- Total services with `isOnSale: true`: 12 services
- Spread across categories (Wedding, Mehndi, Barat, Walima, Birthday, Corporate)
- Enough data to demonstrate multi-page pagination (2 pages)

**Example:**
```javascript
{
  serviceName: 'Royal Wedding Setup',
  // ... other fields ...
  isOnSale: true  // ← Added this field
}
```

---

## 6. How It Works (User Flow)

### 1. **User Navigates to On-Sale Page**
   - URL: `http://localhost:3000/services/onsale-services`
   - Server fetches all services where `isOnSale: true`
   - Server renders `onsale.ejs` with complete service list

### 2. **Page Loads**
   - All service cards are rendered in the DOM but hidden
   - jQuery script runs on document ready
   - First 10 items are displayed
   - "Page 1 of X" indicator is shown
   - Previous button is disabled, Next button is enabled

### 3. **User Clicks "Next"**
   - `currentPage` increments from 1 to 2
   - All items from page 1 are hidden
   - Items 11-20 are shown
   - "Page 2 of X" indicator updates
   - Previous button is enabled

### 4. **User Clicks "Previous"**
   - `currentPage` decrements from 2 to 1
   - All items from page 2 are hidden
   - Items 1-10 are shown
   - "Page 1 of X" indicator updates
   - Previous button is disabled again

### 5. **At Last Page**
   - Next button is disabled and grayed out
   - All remaining items (less than 10) are shown

---

## 7. Key Features

✅ **No Extra API Calls** - All pagination happens on the client side
✅ **Performance Optimized** - Server sends all data once; client-side manipulation is instant
✅ **User Friendly** - Clear page indicators and button state feedback
✅ **Responsive Design** - Uses existing CSS from the project
✅ **Accessibility** - Proper HTML structure and semantic markup
✅ **Error Handling** - Try-catch blocks on server, jQuery selector safety

---

## 8. Testing the Implementation

### To Populate Test Data:
```bash
node seed/servicesData.js
```

### To View On-Sale Services:
1. Start the server: `npm start` or `node server.js`
2. Navigate to: `http://localhost:3000/services/onsale-services`
3. Click through pages using Previous/Next buttons

### Expected Results:
- Page 1 shows services 1-10
- Page 2 shows services 11-12 (or remaining items)
- Navigation buttons work smoothly
- No page reloads occur during pagination

---

## 9. File Modifications Summary

| File | Changes |
|------|---------|
| `models/Service.js` | Added `isOnSale` field to schema |
| `routes/services.js` | Added `/onsale-services` GET route |
| `views/onsale.ejs` | **NEW** - Full on-sale page template with jQuery pagination |
| `seed/servicesData.js` | Added `isOnSale` field to all services (12 marked as true) |

---

## 10. jQuery Selector Reference

| Selector | Purpose |
|----------|---------|
| `.onsale-item` | All service cards (targeted for show/hide) |
| `#product-list` | Container for all service cards |
| `#prev-btn` | Previous button |
| `#next-btn` | Next button |
| `#page-indicator` | Page number display (e.g., "Page 1 of 5") |

---

## 11. Technical Notes

- **jQuery Version:** 3.6.0 (via CDN)
- **Pagination Method:** Client-side DOM manipulation
- **Data Fetching:** Server-side (Mongoose query)
- **Template Engine:** EJS
- **Database:** MongoDB with Mongoose
- **Items Per Page:** 10 (hardcoded, easily configurable)

---

## 12. Future Enhancements (Optional)

- Add keyboard navigation (arrow keys)
- Add pagination dots showing current page
- Add animation effects for transitions
- Add filter options for on-sale items
- Add discount percentage display
- Add "Add to Cart" functionality

