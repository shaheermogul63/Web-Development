// ==========================================
// SEED USERS DATA
// ==========================================
// This script creates demo users for testing authentication

const mongoose = require('mongoose');
const User = require('../models/User');

// MongoDB Connection String
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/majestic-marquee';

// Connect to MongoDB
mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(async () => {
  console.log('✅ MongoDB connected successfully');
  
  try {
    // Delete existing users
    await User.deleteMany({});
    console.log('🗑️  Cleared existing users');

    // Create admin user
    const adminUser = new User({
      name: 'Admin User',
      email: 'admin@majestic.com',
      password: 'password123',
      role: 'admin'
    });

    await adminUser.save();
    console.log('✅ Admin user created:');
    console.log(`   Email: admin@majestic.com`);
    console.log(`   Password: password123`);
    console.log(`   Role: admin`);

    // Create customer user
    const customerUser = new User({
      name: 'John Customer',
      email: 'customer@majestic.com',
      password: 'password123',
      role: 'customer'
    });

    await customerUser.save();
    console.log('\n✅ Customer user created:');
    console.log(`   Email: customer@majestic.com`);
    console.log(`   Password: password123`);
    console.log(`   Role: customer`);

    console.log('\n✨ Demo users created successfully!');
    console.log('\n🔐 Login Credentials:');
    console.log('   Admin: admin@majestic.com / password123');
    console.log('   Customer: customer@majestic.com / password123');

    mongoose.connection.close();
  } catch (error) {
    console.error('❌ Error seeding users:', error.message);
    mongoose.connection.close();
  }
})
.catch(error => {
  console.error('❌ MongoDB connection error:', error.message);
  console.log('⚠️  Make sure MongoDB is running');
});
