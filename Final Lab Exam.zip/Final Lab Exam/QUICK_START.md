<!-- ==========================================
QUICK START GUIDE
========================================== -->

# Getting Started with Majestic Marquee

Complete setup instructions to run the project in 5 minutes.

## Prerequisites

Before starting, ensure you have:
- **Node.js** (v12 or higher) - [Download](https://nodejs.org/)
- **MongoDB** (local or cloud) - [MongoDB Community](https://www.mongodb.com/try/download/community)
- **A Terminal/Command Prompt**
- **Text Editor** (VS Code recommended)

## Step-by-Step Setup

### 1. Install Dependencies (2 minutes)

Open terminal in the project folder and run:

```bash
npm install
```

This installs all required packages listed in `package.json`.

### 2. Configure Environment Variables (1 minute)

The `.env` file is already created with default values:

```
MONGODB_URI=mongodb://localhost:27017/majestic-marquee
PORT=3000
NODE_ENV=development
SESSION_SECRET=your-session-secret-key
JWT_SECRET=your-jwt-secret-key
```

**For Production:** Replace the secret keys with strong values:
```bash
# Generate secure keys using Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### 3. Start MongoDB (varies)

**Option A: Local MongoDB**
```bash
# Open a new terminal and run:
mongod
```

**Option B: MongoDB Atlas (Cloud)**
- Create account at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
- Update `MONGODB_URI` in `.env` with your connection string

### 4. Start the Server (1 minute)

```bash
npm run dev
```

You should see:
```
🚀 Server is running on http://localhost:3000
✅ MongoDB connected successfully
```

### 5. Access the Application

Open your browser and go to:
- **Web Application**: http://localhost:3000
- **Admin Panel**: http://localhost:3000/admin (login as admin first)
- **API**: http://localhost:3000/api/v1

---

## Database Seeding (Optional)

To add sample data for testing:

```bash
# Add sample users (customer + admin accounts)
npm run seed:users

# Add sample services/products
npm run seed

# Add both at once
npm run seed:all
```

**Sample Login Credentials:**
```
Email: customer@example.com
Password: password123
Role: customer

Email: admin@example.com
Password: admin123
Role: admin
```

---

## Folder Organization

```
Project Root
├── server.js          → Main application (start here)
├── package.json       → Dependencies & scripts
├── .env               → Configuration (already set)
│
├── models/            → Database schemas
├── routes/            → API & web routes
├── middleware/        → Authentication & processing
├── views/             → HTML templates (EJS)
└── public/            → CSS, JavaScript, Images
```

---

## Common Commands

```bash
# Start with auto-reload (development)
npm run dev

# Start without auto-reload
npm start

# Add database test data
npm run seed:all

# Stop the server
Ctrl + C
```

---

## First Test

### Test the Web Interface

1. Go to http://localhost:3000
2. Click **"Book Now"** → Goes to Services page
3. Click **"Register"** in navbar
4. Create an account
5. Login with your credentials
6. Try booking a service

### Test the API

Use Postman, Thunder Client, or curl:

```bash
# 1. Register a new user
curl -X POST http://localhost:3000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "password123",
    "confirmPassword": "password123"
  }'

# 2. Login to get JWT token
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'

# 3. Get user profile (use token from response)
curl -X GET http://localhost:3000/api/v1/user/profile \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"

# 4. Get all products
curl http://localhost:3000/api/v1/products
```

---

## Troubleshooting

### "Cannot find module 'express'"
```bash
npm install
```

### "MongoDB connection refused"
Ensure MongoDB is running:
```bash
mongod
```

### "Port 3000 already in use"
Change PORT in `.env` file to an available port (e.g., 3001)

### "Images not displaying"
Images should be in `public/images/`. Check:
```
public/
└── images/
    ├── Background.jpeg
    ├── Banquet Hall.jpeg
    ├── Event Setup.jpeg
    ├── Interior.jpeg
    ├── Location View.jpeg
    ├── Wedding Hall.jpeg
    └── Wedding Venue.jpeg
```

---

## Project Features

✅ **User System**: Register, login, roles (customer/admin)  
✅ **Service Catalog**: Browse 50+ services with search & filters  
✅ **Admin Panel**: Manage services and orders  
✅ **Order System**: Place and track orders  
✅ **Responsive Design**: Works on mobile, tablet, desktop  
✅ **RESTful API**: JSON endpoints for external apps  
✅ **Image Gallery**: Photo carousel on homepage  
✅ **Pagination**: Browse services by pages  

---

## File Explanations

| File | Purpose |
|------|---------|
| `server.js` | Main app entry point - starts everything |
| `package.json` | Lists all dependencies and commands |
| `.env` | Configuration settings (database, secrets) |
| `models/` | Database structure definitions |
| `routes/` | Application endpoints and handlers |
| `middleware/` | Login checks and permission validation |
| `views/` | HTML pages (EJS templates) |
| `public/` | Images, CSS, client-side JavaScript |
| `seed/` | Sample data for testing database |

---

## Next Steps

1. ✅ Get the server running (you did this!)
2. 📚 Explore the code in `routes/` folder
3. 🗄️ Check database structure in `models/`
4. 🎨 Customize styles in `public/css/`
5. 🔐 Test the API with Postman
6. 🚀 Deploy to production

---

## Need Help?

Check inline comments in the code:
- Route files: Explains what each endpoint does
- Model files: Shows database structure
- Middleware files: Shows auth logic

---

## Production Deployment

Before deploying:

1. Update `.env`:
   - Change `NODE_ENV=production`
   - Use strong JWT_SECRET and SESSION_SECRET
   - Update MONGODB_URI to production database

2. Start server:
   ```bash
   npm start
   ```

3. Use process manager (PM2):
   ```bash
   npm install -g pm2
   pm2 start server.js --name "majestic-marquee"
   ```

---

**Congratulations!** You now have a fully working wedding venue management system! 🎉

Start exploring and building! 🚀
