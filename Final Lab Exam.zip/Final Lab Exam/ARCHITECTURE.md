<!-- ==========================================
PROJECT ARCHITECTURE & CODE FLOW
========================================== -->

# Architecture Overview

This document explains how all components of the Majestic Marquee application work together.

---

## Application Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    CLIENT (Browser)                          │
│  ┌──────────────┐      ┌──────────────┐    ┌────────────┐   │
│  │  Homepage    │      │  Services    │    │  Admin     │   │
│  │  (EJS)       │      │  (EJS)       │    │  Panel     │   │
│  └──────────────┘      └──────────────┘    └────────────┘   │
└────────────────┬──────────────────────────────────────┬──────┘
                 │                                      │
                 │ HTTP/HTTPS Requests                 │
                 │ (Forms, Links, Fetch)               │
                 ▼                                      ▼
┌─────────────────────────────────────────────────────────────┐
│                  EXPRESS SERVER (server.js)                 │
│                                                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │  MIDDLEWARE STACK                                   │    │
│  │  1. Express.json()           - Parse JSON requests │    │
│  │  2. Session management       - Handle cookies      │    │
│  │  3. Flash messages          - Display notifications│    │
│  │  4. Auth middleware         - Check permissions    │    │
│  │  5. API auth middleware     - Verify JWT tokens    │    │
│  └────────────────────────────────────────────────────┘    │
│                          │                                   │
│  ┌──────────────────────┴──────────────────────────┐       │
│  │  ROUTES (Request Handlers)                      │       │
│  │                                                   │       │
│  │  ┌─────────────┐  ┌──────────┐  ┌────────────┐ │       │
│  │  │auth.js      │  │admin.js  │  │services.js │ │       │
│  │  │• Register   │  │• CRUD    │  │• List      │ │       │
│  │  │• Login      │  │• Orders  │  │• Filter    │ │       │
│  │  │• Logout     │  │• Stats   │  │• Search    │ │       │
│  │  └─────────────┘  └──────────┘  └────────────┘ │       │
│  │                                                   │       │
│  │  ┌──────────────────────────────────────────┐   │       │
│  │  │api.js (RESTful API)                      │   │       │
│  │  │• Authentication endpoints                │   │       │
│  │  │• Public product endpoints               │   │       │
│  │  │• Protected order endpoints              │   │       │
│  │  │• Admin management endpoints             │   │       │
│  │  └──────────────────────────────────────────┘   │       │
│  └────────────────────────────────────────────────┘       │
│                          │                                   │
└────────────────────────┬─┴──────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        ▼                ▼                ▼
┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐
│   MODELS         │  │  VIEWS (EJS)     │  │ PUBLIC STATIC│
│  (Database      │  │  ┌────────────┐   │  │  ┌────────┐  │
│   Schemas)      │  │  │homepage    │   │  │  │  CSS   │  │
│ ┌────────────┐  │  │  │services    │   │  │  │  JS    │  │
│ │User.js     │  │  │  │login       │   │  │  │Images  │  │
│ │Service.js  │  │  │  │admin/*     │   │  │  └────────┘  │
│ │Order.js    │  │  │  └────────────┘   │  │              │
│ └────────────┘  │  │                    │  │              │
└─────────┬───────┘  └────────────────────┘  └──────────────┘
          │
          ▼
┌──────────────────────────────────────────┐
│        MongoDB (Database)                │
│                                          │
│  ┌──────────────────────────────────┐   │
│  │ Collections:                     │   │
│  │ • users        - Account data    │   │
│  │ • services     - Products        │   │
│  │ • orders       - Customer orders │   │
│  │ • sessions     - Auth sessions   │   │
│  └──────────────────────────────────┘   │
└──────────────────────────────────────────┘
```

---

## Request Flow - Example: User Books a Service

### Step 1: User Visits Services Page
```
Browser → GET /services
   ↓
Express Router (routes/services.js)
   ↓
Handler:
  1. Extract query params (page, category, search)
  2. Query MongoDB Service collection
  3. Calculate pagination
  4. Render views/services.ejs with data
   ↓
HTML page with services + booking buttons
   ↓
Browser displays page
```

### Step 2: User Clicks "Book Now" (Not Logged In)
```
Browser → JavaScript (services.ejs)
   ↓
bookService() function:
  1. Check isUserLoggedIn variable (false)
  2. Redirect: window.location.href = '/auth/login'
   ↓
Browser → GET /auth/login
   ↓
Express Router (routes/auth.js)
   ↓
Handler:
  1. Check middleware: alreadyLoggedIn (passes because not logged in)
  2. Render views/login.ejs
   ↓
Browser displays login form
```

### Step 3: User Logs In
```
Browser → POST /auth/login (form submission)
   ↓
Express Router (routes/auth.js)
   ↓
Handler:
  1. Get email & password from request body
  2. Query User from MongoDB
  3. Compare password with bcryptjs
  4. Create session: req.session.user = {...}
  5. Flash success message
  6. Redirect to dashboard
   ↓
Browser stores session cookie
   ↓
Subsequent requests include session cookie
   ↓
Middleware checks: if (req.session.user) → Logged in!
```

### Step 4: User Books Service (Now Logged In)
```
Browser → Click "Book Now"
   ↓
JavaScript (services.ejs):
  1. Check isUserLoggedIn (true)
  2. Show alert confirmation
   ↓
Browser displays alert
```

---

## Authentication Methods Compared

### Session-Based (Web Interface)
```
1. User submits login form
   ↓
2. Server validates credentials
   ↓
3. Server creates session in MongoDB
   ↓
4. Server sends Set-Cookie header with session ID
   ↓
5. Browser stores cookie
   ↓
6. Every request includes cookie
   ↓
7. Server looks up session in MongoDB
   ↓
8. User info populated in req.session.user
```

### JWT-Based (API)
```
1. Client sends POST /api/v1/auth/login
   ↓
2. Server validates credentials
   ↓
3. Server generates JWT token:
   jwt.sign({user_id, email, role}, JWT_SECRET)
   ↓
4. Server sends token in response
   ↓
5. Client stores token (localStorage/sessionStorage)
   ↓
6. Client sends: Authorization: Bearer <token>
   ↓
7. Server extracts token from header
   ↓
8. Server verifies signature with JWT_SECRET
   ↓
9. Server decodes token
   ↓
10. User info populated in req.user
```

---

## Data Flow: Creating a New Service

### Admin Perspective
```
1. Admin clicks "Add Service" in admin panel
   ↓
2. Browser: GET /admin/add
   ↓
3. Server (routes/admin.js):
   - Check middleware: isAdmin
   - If not admin: redirect to home
   - If admin: render add-service form
   ↓
4. Browser displays form with fields:
   - Service name
   - Description
   - Price
   - Category (dropdown)
   - Rating
   - Image upload
   ↓
5. Admin fills form and clicks "Submit"
   ↓
6. Browser: POST /admin/add (with FormData including image)
   ↓
7. Multer middleware:
   - Checks file type (must be image)
   - Checks file size (max 5MB)
   - Saves to public/uploads/
   - Adds filename to req.file
   ↓
8. Route handler (routes/admin.js):
   - Validates all fields
   - Creates Service model instance
   - Sets image path: /uploads/[filename]
   - service.save() → MongoDB
   ↓
9. MongoDB:
   - Inserts new document in 'services' collection
   - Generates ObjectId
   - Returns saved document
   ↓
10. Server:
    - Show success flash message
    - Redirect to dashboard
   ↓
11. Browser:
    - Displays "Service added successfully"
    - Refreshes services list
```

---

## Admin Panel Routes & Handlers

### GET /admin (Dashboard)
```
Middleware Check:
  ↓
  isLoggedIn?
    No  → Redirect to /auth/login
    Yes → isAdmin?
          No  → Redirect to / with error
          Yes → Continue

Handler:
  1. Service.find() → Get all services from MongoDB
  2. Calculate statistics (count, average price, categories)
  3. res.render('admin-layout', {
       content: 'admin/dashboard',
       services: services,
       ...stats
     })
  4. Render dashboard page showing:
     - Service list
     - Edit buttons
     - Delete buttons
     - Add new service button
```

### POST /admin/add (Create Service)
```
Middleware Check:
  ↓
  isLoggedIn? → isAdmin? → upload.single('image')

Upload Handler (Multer):
  1. Receive file in req.body.image
  2. Validate mime type
  3. Save to public/uploads/
  4. Add to req.file.filename

Route Handler:
  1. Validate all required fields
  2. Create new Service({...})
  3. Set image path from req.file
  4. service.save()
  5. Flash success
  6. Redirect to dashboard
```

### PATCH /admin/:id (Update Service)
```
Handler:
  1. Get service ID from URL params
  2. Validate all fields
  3. Service.findByIdAndUpdate(id, {...}, {new: true})
  4. Flash success
  5. Redirect to dashboard
```

### DELETE /admin/:id (Delete Service)
```
Handler:
  1. Get service ID from URL params
  2. Service.findByIdAndDelete(id)
  3. Flash success
  4. Redirect to dashboard
```

---

## API Endpoint Architecture

### Public Endpoints (No Auth Required)
```
GET /api/v1/products
├─ Query: page, limit, category, search
├─ Handler: No middleware checks
├─ Database: Service.find(filter)
└─ Response: JSON array of products

GET /api/v1/products/:id
├─ Params: service MongoDB ID
├─ Handler: No middleware checks
├─ Database: Service.findById(id)
└─ Response: Single product JSON
```

### Protected Endpoints (JWT Required)
```
Middleware Chain:
  ↓
  1. verifyToken (checks Authorization header)
     - No header → 401 Unauthorized
     - Invalid token → 403 Forbidden
     - Expired → 401 Token expired
     - Valid → Decode and attach to req.user
  ↓
  2. Route handler

Example: GET /api/v1/user/profile
├─ Requires: Authorization: Bearer <token>
├─ Middleware: verifyToken
├─ Handler: 
│   1. Get user ID from req.user.id
│   2. User.findById(req.user.id)
│   3. Return user profile
└─ Response: {success, data: {user}}

Example: POST /api/v1/orders
├─ Requires: Authorization: Bearer <token>
├─ Middleware: verifyToken
├─ Handler:
│   1. Validate order data
│   2. Create Order with req.user.id
│   3. order.save()
│   4. Populate references
│   5. Return saved order
└─ Response: {success, data: {order}}
```

### Admin Endpoints (JWT + Admin Role Required)
```
Middleware Chain:
  ↓
  1. verifyToken
     - Validates JWT
     - Populates req.user
  ↓
  2. verifyAdmin
     - Checks if req.user.role === 'admin'
     - Returns 403 if not admin
  ↓
  3. Route handler

Example: GET /api/v1/admin/orders
├─ Requires: 
│   - Valid JWT token
│   - User role must be 'admin'
├─ Handler:
│   1. Order.find() (all orders, not filtered)
│   2. Populate user and service details
│   3. Apply pagination
│   4. Return all orders
└─ Response: {success, data: {orders, pagination}}

Example: PATCH /api/v1/admin/orders/:id/status
├─ Requires:
│   - Valid JWT token
│   - User role must be 'admin'
│   - Valid order ID
│   - Valid status value
├─ Handler:
│   1. Validate status is valid enum
│   2. Order.findByIdAndUpdate(id, {status}, {new: true})
│   3. Return updated order
└─ Response: {success, data: {order}}
```

---

## Middleware Execution Order

```
Request comes in
   ↓
1. express.json() 
   └─ Parses request body
   ↓
2. express.static('public')
   └─ Serves static files (CSS, JS, images)
   ↓
3. express-session
   └─ Manages session cookies
   ↓
4. connect-flash
   └─ Initializes flash messages
   ↓
5. Custom middleware
   ├─ Populates res.locals with user & flash data
   └─ Makes them available in all templates
   ↓
6. Route-specific middleware
   ├─ auth.js: isLoggedIn, isAdmin, alreadyLoggedIn
   ├─ api-auth.js: verifyToken, verifyAdmin
   └─ multer: upload.single('image')
   ↓
7. Route handler
   └─ Sends response
   ↓
8. Response sent to browser
```

---

## Database Operations

### Mongoose Model Methods

**User Model:**
```javascript
// Pre-save hook: Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, salt);
})

// Instance method: Compare passwords
await user.comparePassword('plaintext') → boolean

// Query: Find by email
User.findOne({email: 'test@example.com'})

// Query: Find by ID
User.findById(userId)
```

**Service Model:**
```javascript
// Query: Find all
Service.find()

// Query: Find by ID
Service.findById(serviceId)

// Query: Find with filters
Service.find({category: 'Wedding'})

// Query: Count documents
Service.countDocuments({filter})

// Query: Get unique values
Service.distinct('category')

// Mutation: Create & save
const service = new Service({...})
await service.save()

// Mutation: Update by ID
Service.findByIdAndUpdate(id, {updates}, {new: true})

// Mutation: Delete by ID
Service.findByIdAndDelete(id)
```

**Order Model:**
```javascript
// Query: Find orders by user
Order.find({user: userId})

// Query: Find with population
Order.findById(orderId)
  .populate('user', 'name email')
  .populate('services.serviceId')

// Mutation: Create
const order = new Order({...})
await order.save()

// Mutation: Update status
Order.findByIdAndUpdate(id, {status: 'confirmed'})

// Instance method: Calculate total
order.calculateTotal() → sum of (price * quantity)
```

---

## Error Handling Flow

### Web Routes (Express)
```
Error occurs in try block
   ↓
catch (error) {
  console.error(error)
  req.flash('error', 'User-friendly message')
  res.redirect('/previous-page')
}
   ↓
Browser shows error message via flash
```

### API Routes (RESTful)
```
Error occurs
   ↓
catch (error) {
  if (error.name === 'TokenExpiredError') → 401 with message
  else if (error.name === 'JsonWebTokenError') → 403 with message
  else if (error.code === 11000) → 409 (duplicate key)
  else if (error.errors) → 400 (validation)
  else → 500 (server error)
}
   ↓
res.status(code).json({
  success: false,
  message: 'Error description',
  error: 'Technical details'
})
   ↓
Client receives JSON error response
```

---

## Session Flow

### User Login
```
1. User submits form
2. Server validates credentials
3. req.session.user = {id, name, email, role}
4. Session data saved in MongoDB 'sessions' collection
5. Server sends Set-Cookie with sessionID
```

### User Makes Subsequent Request
```
1. Browser sends cookie with request
2. Express-session middleware intercepts
3. Looks up sessionID in MongoDB
4. Populates req.session.user with stored data
5. Handler can access req.session.user
6. render() or res.locals makes user available in templates
```

### User Logout
```
1. User clicks logout link
2. GET /auth/logout
3. req.session.destroy()
4. Session deleted from MongoDB
5. Cookie cleared from browser
6. Next request: req.session.user is undefined
```

---

## File Upload Process

```
1. User submits form with file
   Content-Type: multipart/form-data

2. Multer middleware intercepts
   ├─ Checks file size limit (5MB)
   ├─ Checks MIME type (image/*only)
   ├─ Generates unique filename
   ├─ Saves to public/uploads/
   └─ Adds to req.file

3. Route handler
   ├─ Gets filename from req.file.filename
   ├─ Creates path: /uploads/[filename]
   ├─ Stores path in database
   └─ Creates document

4. Browser later requests image
   GET /uploads/filename.jpg
   
5. Express.static('public') serves file
   └─ Client receives image
```

---

## Summary

This architecture provides:
- ✅ **Separation of Concerns**: Models, routes, views separate
- ✅ **Middleware Pipeline**: Each request goes through proper checks
- ✅ **Two Auth Methods**: Sessions for web, JWT for API
- ✅ **Error Handling**: Different responses for web vs API
- ✅ **Database Abstraction**: MongoDB accessed through Mongoose models
- ✅ **Scalability**: Easy to add new routes and models

All components work together to create a secure, organized, and maintainable application!
