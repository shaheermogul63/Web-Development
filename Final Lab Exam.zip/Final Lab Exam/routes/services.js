// ==========================================
// SERVICES ROUTE
// ==========================================
// This route handles:
// - Fetching services from MongoDB
// - Server-side pagination (8 per page)
// - Filtering by category
// - Searching by service name/category

const express = require('express');
const Service = require('../models/Service');
const router = express.Router();

// SERVICES PAGE ROUTE
// Handles pagination, filtering, and searching
router.get('/', async (req, res) => {
  try {
    // Get query parameters
    const page = parseInt(req.query.page) || 1;
    const category = req.query.category || '';
    const search = req.query.search || '';
    const itemsPerPage = 8;

    // Build filter object
    let filter = {};

    // Add category filter if provided
    if (category && category !== 'All') {
      filter.category = category;
    }

    // Add search filter if provided
    // Search in both serviceName and category
    if (search) {
      filter.$or = [
        { serviceName: { $regex: search, $options: 'i' } },
        { category: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    // Calculate pagination
    const totalServices = await Service.countDocuments(filter);
    const totalPages = Math.ceil(totalServices / itemsPerPage);
    const skipAmount = (page - 1) * itemsPerPage;

    // Validate page number
    if (page > totalPages && totalPages > 0) {
      return res.redirect(`/services?page=1${category ? `&category=${category}` : ''}${search ? `&search=${search}` : ''}`);
    }

    // Fetch services from database
    const services = await Service.find(filter)
      .limit(itemsPerPage)
      .skip(skipAmount)
      .sort({ createdAt: -1 });

    // Fetch all categories for the filter dropdown
    const allCategories = await Service.distinct('category');

    // Prepare pagination data
    const paginationData = {
      currentPage: page,
      totalPages: totalPages,
      totalServices: totalServices,
      servicesOnPage: services.length,
      hasPrevious: page > 1,
      hasNext: page < totalPages,
      previousPage: page - 1,
      nextPage: page + 1,
      pages: generatePageNumbers(page, totalPages)
    };

    // Render the services view with data
    res.render('services', {
      services: services,
      categories: allCategories,
      currentCategory: category,
      searchQuery: search,
      pagination: paginationData
    });
  } catch (error) {
    console.error('Error fetching services:', error);
    res.status(500).render('404', {
      message: 'Error loading services'
    });
  }
});

// ON-SALE SERVICES PAGE ROUTE
// Client-side pagination with jQuery (10 items per page)
router.get('/onsale-services', async (req, res) => {
  try {
    // Fetch all services where isOnSale is true
    const onSaleServices = await Service.find({ isOnSale: true })
      .sort({ createdAt: -1 });

    // Render the on-sale view with all on-sale services
    res.render('onsale', {
      services: onSaleServices,
      totalServices: onSaleServices.length
    });
  } catch (error) {
    console.error('Error fetching on-sale services:', error);
    res.status(500).render('404', {
      message: 'Error loading on-sale services'
    });
  }
});

// INDIVIDUAL SERVICE DETAILS ROUTE (Optional - for future use)
router.get('/:id', async (req, res) => {
  try {
    const service = await Service.findById(req.params.id);
    
    if (!service) {
      return res.status(404).render('404', {
        message: 'Service not found'
      });
    }

    res.render('service-detail', { service });
  } catch (error) {
    console.error('Error fetching service:', error);
    res.status(500).render('404', {
      message: 'Error loading service details'
    });
  }
});

// Helper function to generate page numbers for pagination
function generatePageNumbers(currentPage, totalPages) {
  const pages = [];
  const maxPagesToShow = 5;
  let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
  let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);

  // Adjust start if we're near the end
  if (endPage - startPage + 1 < maxPagesToShow) {
    startPage = Math.max(1, endPage - maxPagesToShow + 1);
  }

  for (let i = startPage; i <= endPage; i++) {
    pages.push(i);
  }

  return pages;
}

module.exports = router;
