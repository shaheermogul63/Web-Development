// ==========================================
// AUTHENTICATION ROUTES
// ==========================================
// This file handles user authentication:
// - Registration (create new account)
// - Login (verify credentials and create session)
// - Logout (destroy session)

const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { alreadyLoggedIn } = require('../middleware/auth');

// ==========================================
// GET: Register Page
// ==========================================
// Display the registration form
router.get('/register', alreadyLoggedIn, (req, res) => {
  res.render('register');
});

// ==========================================
// POST: Handle Registration
// ==========================================
// Create a new user account with hashed password
router.post('/register', alreadyLoggedIn, async (req, res) => {
  try {
    const { name, email, password, confirmPassword } = req.body;

    // Validation: Check if all fields are provided
    if (!name || !email || !password || !confirmPassword) {
      req.flash('error', 'Please fill in all fields');
      return res.redirect('/auth/register');
    }

    // Validation: Check if passwords match
    if (password !== confirmPassword) {
      req.flash('error', 'Passwords do not match');
      return res.redirect('/auth/register');
    }

    // Validation: Check password length
    if (password.length < 6) {
      req.flash('error', 'Password must be at least 6 characters');
      return res.redirect('/auth/register');
    }

    // Check if email already exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      req.flash('error', 'Email is already registered. Please use a different email.');
      return res.redirect('/auth/register');
    }

    // Create new user (password will be hashed by the pre-save hook)
    const newUser = new User({
      name,
      email: email.toLowerCase(),
      password,
      role: 'customer' // Default role
    });

    // Save user to database
    await newUser.save();

    // Success message and redirect
    req.flash('success', `Welcome ${name}! Your account has been created. Please log in.`);
    res.redirect('/auth/login');
  } catch (error) {
    console.error('Registration error:', error);
    
    // Handle validation errors from mongoose
    if (error.errors) {
      const messages = Object.values(error.errors).map(err => err.message);
      req.flash('error', messages.join(', '));
    } else if (error.code === 11000) {
      req.flash('error', 'Email is already registered');
    } else {
      req.flash('error', 'An error occurred during registration. Please try again.');
    }
    
    res.redirect('/auth/register');
  }
});

// ==========================================
// GET: Login Page
// ==========================================
// Display the login form
router.get('/login', alreadyLoggedIn, (req, res) => {
  res.render('login');
});

// ==========================================
// POST: Handle Login
// ==========================================
// Authenticate user and create session
router.post('/login', alreadyLoggedIn, async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validation: Check if email and password are provided
    if (!email || !password) {
      req.flash('error', 'Please enter email and password');
      return res.redirect('/auth/login');
    }

    // Find user by email (select password field explicitly since it's not selected by default)
    const user = await User.findOne({ email: email.toLowerCase() }).select('+password');

    // Check if user exists
    if (!user) {
      req.flash('error', 'Invalid email or password');
      return res.redirect('/auth/login');
    }

    // Compare passwords using the method we defined in User model
    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      req.flash('error', 'Invalid email or password');
      return res.redirect('/auth/login');
    }

    // Create session - store user data (without password)
    req.session.user = {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role
    };

    // Flash success message
    req.flash('success', `Welcome back, ${user.name}!`);

    // Redirect based on user role
    if (user.role === 'admin') {
      res.redirect('/admin');
    } else {
      res.redirect('/');
    }
  } catch (error) {
    console.error('Login error:', error);
    req.flash('error', 'An error occurred during login. Please try again.');
    res.redirect('/auth/login');
  }
});

// ==========================================
// GET: Handle Logout
// ==========================================
// Destroy session and redirect to home
router.get('/logout', (req, res) => {
  if (req.session.user) {
    const userName = req.session.user.name;
    
    // Set flash message BEFORE destroying the session
    req.flash('success', `Goodbye, ${userName}! You have successfully logged out.`);
    
    // Destroy session
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.redirect('/');
      }

      // Clear session cookie
      res.clearCookie('connect.sid');
      res.redirect('/');
    });
  } else {
    res.redirect('/');
  }
});

module.exports = router;
