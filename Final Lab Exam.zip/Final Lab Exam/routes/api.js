// ==========================================
// API V1 ROUTES (HEADLESS API)
// ==========================================
// This file contains RESTful API endpoints for a headless architecture
// Supports JWT-based authentication for external clients (mobile apps, React frontends, etc.)

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Service = require('../models/Service');
const Order = require('../models/Order');
const { verifyToken, verifyAdmin } = require('../middleware/api-auth');

// ==========================================
// HELPER FUNCTION: Generate JWT Token
// ==========================================
const generateToken = (user) => {
  return jwt.sign(
    {
      user_id: user._id,
      email: user.email,
      role: user.role
    },
    process.env.JWT_SECRET || 'your-secret-key-change-in-production',
    {
      expiresIn: '24h' // Token expires in 24 hours
    }
  );
};

// ==========================================
// HELPER FUNCTION: Error Response
// ==========================================
const sendError = (res, statusCode, message, error = null) => {
  return res.status(statusCode).json({
    success: false,
    message,
    ...(error && { error })
  });
};

// ==========================================
// HELPER FUNCTION: Success Response
// ==========================================
const sendSuccess = (res, statusCode, message, data = null) => {
  return res.status(statusCode).json({
    success: true,
    message,
    ...(data && { data })
  });
};

// ==========================================
// AUTH ENDPOINTS
// ==========================================

// POST /api/v1/auth/login - User Login (Generate JWT Token)
router.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validation: Check if email and password are provided
    if (!email || !password) {
      return sendError(res, 400, 'Please provide email and password');
    }

    // Find user by email and explicitly select password field
    const user = await User.findOne({ email: email.toLowerCase() }).select('+password');

    // Check if user exists
    if (!user) {
      return sendError(res, 401, 'Invalid email or password');
    }

    // Compare passwords
    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      return sendError(res, 401, 'Invalid email or password');
    }

    // Generate JWT token
    const token = generateToken(user);

    // Return success response with token
    return sendSuccess(res, 200, 'Login successful', {
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    return sendError(res, 500, 'Server error during login', error.message);
  }
});

// POST /api/v1/auth/register - User Registration
router.post('/auth/register', async (req, res) => {
  try {
    const { name, email, password, confirmPassword } = req.body;

    // Validation: Check if all fields are provided
    if (!name || !email || !password || !confirmPassword) {
      return sendError(res, 400, 'Please fill in all fields');
    }

    // Validation: Check if passwords match
    if (password !== confirmPassword) {
      return sendError(res, 400, 'Passwords do not match');
    }

    // Validation: Check password length
    if (password.length < 6) {
      return sendError(res, 400, 'Password must be at least 6 characters');
    }

    // Check if email already exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return sendError(res, 409, 'Email is already registered');
    }

    // Create new user
    const newUser = new User({
      name,
      email: email.toLowerCase(),
      password,
      role: 'customer'
    });

    // Save user to database (password will be hashed by pre-save hook)
    await newUser.save();

    // Generate JWT token
    const token = generateToken(newUser);

    // Return success response
    return sendSuccess(res, 201, 'Registration successful. You are now logged in.', {
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role
      }
    });
  } catch (error) {
    console.error('Registration error:', error);

    // Handle validation errors
    if (error.errors) {
      const messages = Object.values(error.errors).map(err => err.message);
      return sendError(res, 400, messages.join(', '));
    }

    if (error.code === 11000) {
      return sendError(res, 409, 'Email is already registered');
    }

    return sendError(res, 500, 'Server error during registration', error.message);
  }
});

// ==========================================
// PUBLIC PRODUCT/SERVICE ENDPOINTS
// ==========================================

// GET /api/v1/products - Get all products with pagination and filtering
router.get('/products', async (req, res) => {
  try {
    const { page = 1, limit = 10, category, search } = req.query;

    // Build filter object
    const filter = {};

    // Add category filter
    if (category) {
      filter.category = category;
    }

    // Add search filter (searches serviceName and description)
    if (search) {
      filter.$or = [
        { serviceName: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Fetch services
    const services = await Service.find(filter)
      .limit(parseInt(limit))
      .skip(skip)
      .sort({ createdAt: -1 });

    // Get total count for pagination info
    const totalServices = await Service.countDocuments(filter);
    const totalPages = Math.ceil(totalServices / parseInt(limit));

    return sendSuccess(res, 200, 'Products retrieved successfully', {
      products: services,
      pagination: {
        totalServices,
        currentPage: parseInt(page),
        totalPages,
        hasNextPage: parseInt(page) < totalPages,
        hasPreviousPage: parseInt(page) > 1
      }
    });
  } catch (error) {
    console.error('Fetch products error:', error);
    return sendError(res, 500, 'Server error while fetching products', error.message);
  }
});

// GET /api/v1/products/:id - Get single product details
router.get('/products/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Validate MongoDB ObjectId
    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return sendError(res, 400, 'Invalid product ID format');
    }

    // Find service by ID
    const service = await Service.findById(id);

    if (!service) {
      return sendError(res, 404, 'Product not found');
    }

    return sendSuccess(res, 200, 'Product details retrieved successfully', {
      product: service
    });
  } catch (error) {
    console.error('Fetch product details error:', error);
    return sendError(res, 500, 'Server error while fetching product', error.message);
  }
});

// ==========================================
// PROTECTED USER ENDPOINTS
// ==========================================

// GET /api/v1/user/profile - Get authenticated user's profile
router.get('/user/profile', verifyToken, async (req, res) => {
  try {
    // Get user from database using decoded token info
    const user = await User.findById(req.user.id);

    if (!user) {
      return sendError(res, 404, 'User not found');
    }

    return sendSuccess(res, 200, 'User profile retrieved successfully', {
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        createdAt: user.createdAt
      }
    });
  } catch (error) {
    console.error('Fetch user profile error:', error);
    return sendError(res, 500, 'Server error while fetching profile', error.message);
  }
});

// ==========================================
// PROTECTED ORDER ENDPOINTS
// ==========================================

// POST /api/v1/orders - Create a new order
router.post('/orders', verifyToken, async (req, res) => {
  try {
    const { services, totalPrice, eventDate, eventType, notes } = req.body;

    // Validation: Check required fields
    if (!services || !Array.isArray(services) || services.length === 0) {
      return sendError(res, 400, 'Please provide at least one service');
    }

    if (!eventDate) {
      return sendError(res, 400, 'Please provide an event date');
    }

    if (!eventType) {
      return sendError(res, 400, 'Please specify the event type');
    }

    // Validate that all services exist
    const serviceIds = services.map(s => s.serviceId);
    const existingServices = await Service.find({ _id: { $in: serviceIds } });

    if (existingServices.length !== services.length) {
      return sendError(res, 400, 'One or more services not found');
    }

    // Calculate total price if not provided
    let calculatedTotal = totalPrice;
    if (!calculatedTotal) {
      calculatedTotal = services.reduce((sum, service) => {
        return sum + (service.price * (service.quantity || 1));
      }, 0);
    }

    // Create new order
    const newOrder = new Order({
      user: req.user.id,
      services,
      totalPrice: calculatedTotal,
      eventDate,
      eventType,
      notes,
      status: 'pending'
    });

    // Save order to database
    await newOrder.save();

    // Populate user and service details
    await newOrder.populate('user', 'name email');
    await newOrder.populate('services.serviceId');

    return sendSuccess(res, 201, 'Order created successfully', {
      order: newOrder
    });
  } catch (error) {
    console.error('Create order error:', error);

    if (error.errors) {
      const messages = Object.values(error.errors).map(err => err.message);
      return sendError(res, 400, messages.join(', '));
    }

    return sendError(res, 500, 'Server error while creating order', error.message);
  }
});

// GET /api/v1/orders - Get user's orders (protected)
router.get('/orders', verifyToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;

    // Build filter
    const filter = { user: req.user.id };

    if (status) {
      filter.status = status;
    }

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Fetch orders
    const orders = await Order.find(filter)
      .populate('user', 'name email')
      .populate('services.serviceId', 'serviceName description price')
      .limit(parseInt(limit))
      .skip(skip)
      .sort({ createdAt: -1 });

    // Get total count
    const totalOrders = await Order.countDocuments(filter);
    const totalPages = Math.ceil(totalOrders / parseInt(limit));

    return sendSuccess(res, 200, 'Orders retrieved successfully', {
      orders,
      pagination: {
        totalOrders,
        currentPage: parseInt(page),
        totalPages,
        hasNextPage: parseInt(page) < totalPages,
        hasPreviousPage: parseInt(page) > 1
      }
    });
  } catch (error) {
    console.error('Fetch orders error:', error);
    return sendError(res, 500, 'Server error while fetching orders', error.message);
  }
});

// GET /api/v1/orders/:id - Get specific order details
router.get('/orders/:id', verifyToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Validate MongoDB ObjectId
    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return sendError(res, 400, 'Invalid order ID format');
    }

    // Find order
    const order = await Order.findById(id)
      .populate('user', 'name email')
      .populate('services.serviceId');

    if (!order) {
      return sendError(res, 404, 'Order not found');
    }

    // Check if order belongs to authenticated user
    if (order.user._id.toString() !== req.user.id) {
      return sendError(res, 403, 'You do not have permission to access this order');
    }

    return sendSuccess(res, 200, 'Order details retrieved successfully', {
      order
    });
  } catch (error) {
    console.error('Fetch order details error:', error);
    return sendError(res, 500, 'Server error while fetching order', error.message);
  }
});

// ==========================================
// ADMIN-ONLY ENDPOINTS
// ==========================================

// GET /api/v1/admin/orders - Get all orders (admin only)
router.get('/admin/orders', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;

    // Build filter
    const filter = {};

    if (status) {
      filter.status = status;
    }

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Fetch orders
    const orders = await Order.find(filter)
      .populate('user', 'name email')
      .populate('services.serviceId', 'serviceName description price')
      .limit(parseInt(limit))
      .skip(skip)
      .sort({ createdAt: -1 });

    // Get total count
    const totalOrders = await Order.countDocuments(filter);
    const totalPages = Math.ceil(totalOrders / parseInt(limit));

    return sendSuccess(res, 200, 'All orders retrieved successfully', {
      orders,
      pagination: {
        totalOrders,
        currentPage: parseInt(page),
        totalPages,
        hasNextPage: parseInt(page) < totalPages,
        hasPreviousPage: parseInt(page) > 1
      }
    });
  } catch (error) {
    console.error('Fetch all orders error:', error);
    return sendError(res, 500, 'Server error while fetching orders', error.message);
  }
});

// PATCH /api/v1/admin/orders/:id/status - Update order status (admin only)
router.patch('/admin/orders/:id/status', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    // Validation
    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return sendError(res, 400, 'Invalid order ID format');
    }

    if (!status) {
      return sendError(res, 400, 'Please provide a status');
    }

    if (!['pending', 'confirmed', 'completed', 'cancelled'].includes(status)) {
      return sendError(res, 400, 'Invalid status value');
    }

    // Update order
    const order = await Order.findByIdAndUpdate(
      id,
      { status },
      { new: true, runValidators: true }
    ).populate('user', 'name email');

    if (!order) {
      return sendError(res, 404, 'Order not found');
    }

    return sendSuccess(res, 200, 'Order status updated successfully', {
      order
    });
  } catch (error) {
    console.error('Update order status error:', error);
    return sendError(res, 500, 'Server error while updating order', error.message);
  }
});

module.exports = router;
