// ==========================================
// ORDER MODEL (MONGOOSE SCHEMA)
// ==========================================
// This file defines the MongoDB schema for customer orders
// It tracks orders placed by users, the services they ordered, and order status

const mongoose = require('mongoose');

// Define the Order Schema
const orderSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Please provide a user ID']
  },
  services: [
    {
      serviceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Service',
        required: true
      },
      serviceName: {
        type: String,
        required: true
      },
      price: {
        type: Number,
        required: true
      },
      quantity: {
        type: Number,
        default: 1,
        min: [1, 'Quantity must be at least 1']
      }
    }
  ],
  totalPrice: {
    type: Number,
    required: true,
    min: [0, 'Total price cannot be negative']
  },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'completed', 'cancelled'],
    default: 'pending'
  },
  eventDate: {
    type: Date,
    required: [true, 'Please provide an event date']
  },
  eventType: {
    type: String,
    enum: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events'],
    required: [true, 'Please specify the event type']
  },
  notes: {
    type: String,
    trim: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Pre-save hook to update updatedAt field
orderSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Instance method to calculate total price
orderSchema.methods.calculateTotal = function() {
  return this.services.reduce((total, item) => {
    return total + (item.price * item.quantity);
  }, 0);
};

// Create and export the Order model
module.exports = mongoose.model('Order', orderSchema);
