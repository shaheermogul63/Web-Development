// ==========================================
// SERVICE MODEL (MONGOOSE SCHEMA)
// ==========================================
// This file defines the MongoDB schema for Event Services
// It includes service details like name, price, category, rating, availability, and image

const mongoose = require('mongoose');

// Define the Service Schema
const serviceSchema = new mongoose.Schema({
  serviceName: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  price: {
    type: Number,
    required: true
  },
  category: {
    type: String,
    required: true,
    enum: ['Wedding', 'Mehndi', 'Barat', 'Walima', 'Birthday Events', 'Corporate Events'],
    trim: true
  },
  rating: {
    type: Number,
    required: true,
    min: 0,
    max: 5,
    default: 4.5
  },
  availability: {
    type: Boolean,
    required: true,
    default: true
  },
  image: {
    type: String,
    required: true,
    default: '/images/default-service.jpg'
  },
  isOnSale: {
    type: Boolean,
    required: true,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create and export the Service model
module.exports = mongoose.model('Service', serviceSchema);
