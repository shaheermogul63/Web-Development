# Quick Reference Guide - On-Sale Services Feature

## 🚀 Quick Start

### Access the Page
```
http://localhost:3000/services/onsale-services
```

### What You'll See
- List of promotional/on-sale services
- 10 services per page
- Navigation buttons (Previous/Next)
- Page indicator (e.g., "Page 1 of 2")

---

## 🔧 How to Modify

### Change Items Per Page
**File:** `views/onsale.ejs` (line 254)
```javascript
// Change this number to show different items per page
const itemsPerPage = 10;  // Change 10 to your desired number
```

### Mark Services as On-Sale
**Method 1: Via Seed File**
- Edit `seed/servicesData.js`
- Set `isOnSale: true` for any service

**Method 2: Via Mongoose (in Node REPL)**
```javascript
const Service = require('./models/Service');
await Service.updateOne({ _id: serviceId }, { isOnSale: true });
```

**Method 3: Via MongoDB Compass**
- Edit documents directly
- Set `isOnSale` field to `true`

### Customize Appearance
**File:** `views/onsale.ejs`

**Change page header color:**
```html
<section class="services-header" style="background: linear-gradient(135deg, #ff6b6b 0%, #ff8e72 100%);">
```

**Change button colors:**
```html
<button style="background: #007bff;">  <!-- Modify this color -->
```

**Change sale badge text/color:**
```html
<span class="sale-badge" style="background: #ff6b6b;">ON SALE</span>
```

---

## 📊 Data Structure

### Service Schema Fields
```javascript
{
  serviceName: String,      // e.g., "Royal Wedding Setup"
  description: String,      // Service details
  price: Number,           // e.g., 50000
  category: String,        // Wedding, Mehndi, etc.
  rating: Number,          // 0-5 rating
  availability: Boolean,   // Available or not
  image: String,          // Image URL
  isOnSale: Boolean,      // TRUE for on-sale services
  createdAt: Date         // Creation timestamp
}
```

---

## 🎯 Key jQuery Selectors

| Selector | Purpose |
|----------|---------|
| `.onsale-item` | Each service card |
| `#product-list` | Container for all services |
| `#prev-btn` | Previous button |
| `#next-btn` | Next button |
| `#page-indicator` | Page number display |

### Example: Update styles via jQuery
```javascript
// Make all on-sale items have a border
$('.onsale-item').css('border', '2px solid gold');

// Change button text
$('#next-btn').text('Continue →');
```

---

## 🐛 Troubleshooting

### Problem: No services showing
**Solution:**
1. Ensure database is connected
2. Run `npm run seed` to populate data
3. Check console for errors
4. Verify MongoDB is running

### Problem: Pagination not working
**Solution:**
1. Open browser console (F12)
2. Check for JavaScript errors
3. Verify jQuery is loaded
4. Clear browser cache and reload

### Problem: Button styles look wrong
**Solution:**
1. Clear browser cache
2. Reload page (Ctrl+Shift+R)
3. Check if CSS files are loading properly
4. Verify no CSS conflicts

### Problem: "Cannot GET /services/onsale-services"
**Solution:**
1. Ensure server is running (`npm start`)
2. Check database connection
3. Verify route syntax in `routes/services.js`
4. Restart server

---

## 📈 Performance Tips

### To improve performance for many items:
1. **Use pagination** - Already implemented (10 per page)
2. **Add indexing** - Create MongoDB index on `isOnSale`
   ```javascript
   // In models/Service.js
   serviceSchema.index({ isOnSale: 1 });
   ```
3. **Lazy load images** - Add `loading="lazy"` to img tags
4. **Cache results** - Add Redis caching if needed

### Monitor performance:
```javascript
// In browser console
console.time('pagination');
// ... perform pagination ...
console.timeEnd('pagination');
```

---

## 🔗 Integration Examples

### Add link to homepage
**File:** `views/homepage.ejs`
```html
<a href="/services/onsale-services" class="btn">View On-Sale Services</a>
```

### Add to navigation menu
**File:** `views/onsale.ejs`
```html
<li><a href="/services/onsale-services">On-Sale</a></li>  <!-- Already added -->
```

### Add API endpoint
**File:** `routes/api.js`
```javascript
router.get('/onsale', async (req, res) => {
  const services = await Service.find({ isOnSale: true });
  res.json(services);
});
```

---

## 📋 Common Tasks

### Task: Show 15 items per page instead of 10
```javascript
// Line 254 in views/onsale.ejs
const itemsPerPage = 15;
```

### Task: Sort by price instead of date
**File:** `routes/services.js`
```javascript
const onSaleServices = await Service.find({ isOnSale: true })
  .sort({ price: 1 });  // 1 = ascending, -1 = descending
```

### Task: Show only available on-sale services
**File:** `routes/services.js`
```javascript
const onSaleServices = await Service.find({ 
  isOnSale: true,
  availability: true 
}).sort({ createdAt: -1 });
```

### Task: Add a filter by category
```javascript
// In onsale.ejs, add to the route:
router.get('/onsale-services', async (req, res) => {
  const category = req.query.category;
  let filter = { isOnSale: true };
  if (category) filter.category = category;
  
  const onSaleServices = await Service.find(filter);
  res.render('onsale', { services: onSaleServices, ... });
});
```

---

## 💡 Pro Tips

1. **Test locally first** - Always test changes locally before deploying
2. **Check console** - Browser console shows jQuery errors clearly
3. **Use dev tools** - F12 to debug pagination issues
4. **Keep backups** - Backup data before running seed script
5. **Monitor logs** - Check server logs for database errors
6. **Version control** - Commit changes before major modifications

---

## 🎯 Checklist for Adding/Modifying Services

- [ ] Connect to MongoDB
- [ ] Update service `isOnSale` status
- [ ] Verify in compass or mongosh
- [ ] Navigate to `/services/onsale-services`
- [ ] Confirm service appears in list
- [ ] Test pagination if over 10 items
- [ ] Check responsive design (mobile/tablet)
- [ ] Verify all links work
- [ ] Check booking button functionality

---

## 📞 Support Resources

### Files to Reference
- `ON_SALE_IMPLEMENTATION.md` - Technical details
- `ONSALE_COMPLETION_REPORT.md` - Implementation report
- `views/onsale.ejs` - Template code
- `routes/services.js` - Route handler
- `models/Service.js` - Data schema

### Tools
- MongoDB Compass - Database viewer
- Browser DevTools - JavaScript debugging
- Postman - API testing
- VS Code - Code editing

---

## ✅ Verification Commands

### Verify Database
```bash
# In MongoDB shell
use 'majestic-marquee'
db.services.find({ isOnSale: true }).count()  // Should show 12
```

### Verify Server
```bash
npm start
# Should see "✅ MongoDB connected successfully"
```

### Verify Route
```bash
curl http://localhost:3000/services/onsale-services
# Should return HTML page
```

---

## 🎓 Learning Resources

- **jQuery Pagination:** https://jquery.com/
- **EJS Templating:** https://ejs.co/
- **Mongoose Queries:** https://mongoosejs.com/docs/queries.html
- **MongoDB Aggregation:** https://docs.mongodb.com/manual/aggregation/

---

**Last Updated:** May 18, 2026
**Status:** Production Ready ✅

