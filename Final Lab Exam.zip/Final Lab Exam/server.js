// ==========================================
// MAJESTIC MARQUEE EXPRESS SERVER
// ==========================================
// This is the main Express application file
// It sets up the server, configures EJS as the view engine,
// connects to MongoDB, and defines routes for serving pages and services.

// Import the Express framework
const express = require('express');

// Import Mongoose for MongoDB connection
const mongoose = require('mongoose');

// Import session management
const session = require('express-session');
const MongoStore = require('connect-mongo').default;

// Import flash messages
const flash = require('connect-flash');

// Import routes
const servicesRoute = require('./routes/services');
const adminRoute = require('./routes/admin');
const authRoute = require('./routes/auth');
const apiRoute = require('./routes/api');

// Create an Express application instance
const app = express();

// Set the port for the server to listen on
const PORT = 3000;

// ==========================================
// MONGODB CONNECTION
// ==========================================

// MongoDB Connection String
// For local MongoDB: mongodb://localhost:27017/majestic-marquee
// For MongoDB Atlas: mongodb+srv://username:password@cluster.mongodb.net/majestic-marquee
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/majestic-marquee';

// Connect to MongoDB
mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('✅ MongoDB connected successfully');
})
.catch(error => {
  console.error('❌ MongoDB connection error:', error.message);
  console.log('⚠️  Server is running without database. Services will not work.');
  console.log('💡 To fix: Install MongoDB locally or provide MONGODB_URI environment variable');
});

// ==========================================
// MIDDLEWARE CONFIGURATION
// ==========================================

// Set EJS as the view engine
// This tells Express to use EJS for rendering HTML templates
app.set('view engine', 'ejs');

// Set the directory where EJS templates (views) are stored
// By default, Express looks for views in a folder called 'views'
app.set('views', './views');

// Serve static files (CSS, JavaScript, images) from the 'public' directory
// With this middleware, files in 'public/' are served at the root URL (/)
// Example: public/css/style.css is accessible at /css/style.css
app.use(express.static('public'));

// Parse incoming JSON request bodies
app.use(express.json());

// Parse incoming form data (URL-encoded)
app.use(express.urlencoded({ extended: true }));

// ==========================================
// SESSION & AUTHENTICATION MIDDLEWARE
// ==========================================

// Configure express-session with MongoDB store for persistent sessions
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  store: new MongoStore({
    mongoUrl: MONGODB_URI,
    collectionName: 'sessions'
  }),
  cookie: {
    maxAge: 1000 * 60 * 60 * 24, // 24 hours
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production' // HTTPS only in production
  }
}));

// Initialize flash messages
app.use(flash());

// Middleware to make user and flash messages available in all views
app.use((req, res, next) => {
  // Make user object available in all templates
  res.locals.user = req.session.user || null;
  
  // Make flash messages available in all templates
  res.locals.success = req.flash('success');
  res.locals.error = req.flash('error');
  res.locals.warning = req.flash('warning');
  res.locals.info = req.flash('info');
  
  next();
});


// ==========================================
// ROUTES
// ==========================================

// Authentication routes - register, login, logout
app.use('/auth', authRoute);

// Home route - serves the main landing page
app.get('/', (req, res) => {
  // res.render() finds the EJS template in the 'views' folder and sends it to the client
  // 'homepage' will render 'views/homepage.ejs'
  res.render('homepage');
});

// Admin routes - admin panel with CRUD operations
app.use('/admin', adminRoute);

// Services routes - dynamic service catalog with pagination and filtering
app.use('/services', servicesRoute);

// Contact Us route - serves the contact page
app.get('/contact-us', (req, res) => {
  res.render('contact');
});

// ==========================================
// API V1 ROUTES (HEADLESS ARCHITECTURE)
// ==========================================
// RESTful API endpoints with JWT authentication for external clients
app.use('/api/v1', apiRoute);

// ==========================================
// ERROR HANDLING
// ==========================================

// 404 Error - Route not found
app.use((req, res) => {
  res.status(404).render('404');
});

// ==========================================
// START THE SERVER
// ==========================================

// Listen on the specified port
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
  console.log(`\n📄 Routes:`);
  console.log(`   Homepage: http://localhost:${PORT}/`);
  console.log(`   Services: http://localhost:${PORT}/services`);
  console.log(`   Contact: http://localhost:${PORT}/contact-us`);
  console.log(`\n📚 Services Features:`);
  console.log(`   • Pagination: http://localhost:${PORT}/services?page=1`);
  console.log(`   • Filter by Category: http://localhost:${PORT}/services?category=Wedding`);
  console.log(`   • Search: http://localhost:${PORT}/services?search=Mehndi`);
  console.log(`   • Combine: http://localhost:${PORT}/services?page=1&category=Wedding&search=Luxury`);
  console.log(`\n🔐 API V1 Endpoints (Headless Architecture):`);
  console.log(`   Authentication:`);
  console.log(`   • POST http://localhost:${PORT}/api/v1/auth/login`);
  console.log(`   • POST http://localhost:${PORT}/api/v1/auth/register`);
  console.log(`\n   Public Endpoints:`);
  console.log(`   • GET http://localhost:${PORT}/api/v1/products (with pagination/filtering)`);
  console.log(`   • GET http://localhost:${PORT}/api/v1/products/:id`);
  console.log(`\n   Protected Endpoints (requires JWT token):`);
  console.log(`   • GET http://localhost:${PORT}/api/v1/user/profile`);
  console.log(`   • POST http://localhost:${PORT}/api/v1/orders`);
  console.log(`   • GET http://localhost:${PORT}/api/v1/orders`);
  console.log(`   • GET http://localhost:${PORT}/api/v1/orders/:id`);
  console.log(`\n   Admin Endpoints (requires JWT token & admin role):`);
  console.log(`   • GET http://localhost:${PORT}/api/v1/admin/orders`);
  console.log(`   • PATCH http://localhost:${PORT}/api/v1/admin/orders/:id/status`);
  console.log(`\n💡 API Authentication:`);
  console.log(`   • Header: Authorization: Bearer <token>`);
  console.log(`   • Token expires in 24 hours`);
  console.log(`\n🌱 To seed the database:`);
  console.log(`   npm run seed`);
  console.log(`\n💡 Tips:`);
  console.log(`   • Press Ctrl+C to stop the server`);
  console.log(`   • Use 'npm run dev' for auto-restart on file changes`);
  console.log(`   • Install MongoDB Community Edition for local development`);
});
