<!-- ==========================================
MAJESTIC MARQUEE - WEDDING VENUE MANAGEMENT SYSTEM
========================================== -->

# Majestic Marquee - Complete Project

A full-stack web application for managing wedding venue services with both traditional web interface and RESTful API architecture.

## Project Overview

This application provides:
- **Web Interface**: Traditional server-rendered pages using EJS templates
- **Admin Panel**: Complete CRUD operations for services and orders
- **RESTful API**: JWT-authenticated API endpoints for external clients (mobile apps, React frontends)
- **User Management**: Registration, login, and role-based access control
- **Service Catalog**: Browse and book wedding and event services
- **Order System**: Place and track service orders

---

## Folder Structure

```
Final Completed/
│
├── server.js                          # Main Express application entry point
├── package.json                       # Project dependencies and scripts
├── .env                               # Environment variables (local development)
├── .env.example                       # Environment variables template
│
├── middleware/                        # Request processing middleware
│   ├── auth.js                        # Session-based authentication (web)
│   └── api-auth.js                    # JWT-based authentication (API)
│
├── models/                            # MongoDB data schemas
│   ├── User.js                        # User account schema (customers & admins)
│   ├── Service.js                     # Service/product schema
│   └── Order.js                       # Customer order schema
│
├── routes/                            # Application route handlers
│   ├── auth.js                        # Authentication routes (register, login, logout)
│   ├── admin.js                       # Admin panel routes (CRUD operations)
│   ├── services.js                    # Service listing and management routes
│   └── api.js                         # RESTful API v1 endpoints
│
├── views/                             # EJS template files (UI)
│   ├── homepage.ejs                   # Landing page with gallery and info
│   ├── services.ejs                   # Services listing page
│   ├── login.ejs                      # User login page
│   ├── register.ejs                   # User registration page
│   ├── contact.ejs                    # Contact page
│   ├── 404.ejs                        # 404 error page
│   ├── admin-layout.ejs               # Admin panel layout template
│   ├── partials/                      # Reusable template components
│   └── admin/                         # Admin-specific pages
│       ├── dashboard.ejs              # Admin dashboard
│       ├── add-service.ejs            # Add new service form
│       └── edit-service.ejs           # Edit service form
│
├── public/                            # Static files served to clients
│   ├── css/                           # Stylesheets
│   │   ├── style.css                  # Main application styles
│   │   ├── services.css               # Services page styles
│   │   └── admin.css                  # Admin panel styles
│   │
│   ├── js/                            # Client-side JavaScript
│   │   ├── app.js                     # Main application script
│   │   └── services-data.js           # Service data utilities
│   │
│   ├── images/                        # Image assets
│   │   ├── Background.jpeg            # Hero section background
│   │   ├── Banquet Hall.jpeg          # Service image
│   │   ├── Event Setup.jpeg           # Service image
│   │   ├── Interior.jpeg              # Service image
│   │   ├── Location View.jpeg         # Service image
│   │   ├── Wedding Hall.jpeg          # Service image
│   │   └── Wedding Venue.jpeg         # Service image
│   │
│   └── uploads/                       # User-uploaded files
│
├── seed/                              # Database seeding scripts
│   ├── usersData.js                   # Seed sample users
│   └── servicesData.js                # Seed sample services
│
└── code.js                            # Utility or helper code


```

---

## Technology Stack

**Backend:**
- Node.js & Express.js - Web server framework
- MongoDB & Mongoose - Database and ODM
- JWT (jsonwebtoken) - Token-based authentication
- bcryptjs - Password hashing
- Express-session - Session management

**Frontend:**
- EJS - Server-side templating engine
- HTML5 & CSS3 - Markup and styling
- Vanilla JavaScript - Client-side functionality
- Bootstrap concepts - Responsive design

**Development Tools:**
- Nodemon - Auto-restart on file changes
- npm - Package management

---

## Getting Started

### Prerequisites
- Node.js (v12 or higher)
- MongoDB (local or Atlas)
- npm or yarn

### Installation

1. **Install Dependencies**
```bash
npm install
```

2. **Configure Environment Variables**
Create a `.env` file with:
```
MONGODB_URI=mongodb://localhost:27017/majestic-marquee
PORT=3000
NODE_ENV=development
SESSION_SECRET=your-session-secret-key
JWT_SECRET=your-jwt-secret-key
```

3. **Start the Server**
```bash
npm run dev          # With auto-reload (development)
# or
npm start            # Standard start (production)
```

4. **Seed Database (Optional)**
```bash
npm run seed:users   # Add sample users
npm run seed         # Add sample services
npm run seed:all     # Add both
```

5. **Access the Application**
- Web: http://localhost:3000
- API: http://localhost:3000/api/v1

---

## Key Features

### 1. User Authentication
- **Registration**: Create new user accounts
- **Login**: Authenticate with email/password
- **Session Management**: Persistent user sessions
- **Role-Based Access**: Customer and Admin roles

### 2. Web Interface
- **Homepage**: Landing page with service gallery
- **Services Catalog**: Browse services with pagination and filtering
- **Service Details**: View individual service information
- **Contact Page**: Get in touch information

### 3. Admin Panel
- **Dashboard**: Overview of services and orders
- **Service Management**: Add, edit, delete services
- **Order Management**: View and update customer orders
- **Restricted Access**: Admin-only protected routes

### 4. RESTful API (v1)
- **Public Endpoints**: List and search services
- **Authentication**: JWT-based login and registration
- **Protected Endpoints**: Order management for authenticated users
- **Admin Endpoints**: System-wide order management

---

## API Endpoints

### Authentication
```
POST /api/v1/auth/login          # Login with email/password
POST /api/v1/auth/register       # Register new account
```

### Public Products
```
GET  /api/v1/products            # List all products (with filters)
GET  /api/v1/products/:id        # Get product details
```

### Protected User (requires JWT token)
```
GET  /api/v1/user/profile        # Get user profile
POST /api/v1/orders              # Create new order
GET  /api/v1/orders              # Get user's orders
GET  /api/v1/orders/:id          # Get order details
```

### Admin Only (requires JWT token + admin role)
```
GET  /api/v1/admin/orders        # List all orders
PATCH /api/v1/admin/orders/:id/status # Update order status
```

---

## Database Models

### User Schema
- name (String)
- email (String, unique)
- password (String, hashed)
- role (String: 'customer' or 'admin')
- createdAt (Date)

### Service Schema
- serviceName (String)
- description (String)
- price (Number)
- category (String: Wedding, Mehndi, Barat, Walima, Birthday, Corporate)
- rating (Number: 0-5)
- availability (Boolean)
- image (String)
- createdAt (Date)

### Order Schema
- user (ObjectId, references User)
- services (Array of service details)
- totalPrice (Number)
- status (String: pending, confirmed, completed, cancelled)
- eventDate (Date)
- eventType (String)
- notes (String)
- createdAt (Date)
- updatedAt (Date)

---

## Authentication Methods

### Session-Based (Web Interface)
- Cookies are automatically managed by Express-session
- Secure, httpOnly cookies for production
- 24-hour session expiration

### JWT-Based (API)
- Token format: `Authorization: Bearer <token>`
- Token payload includes: user_id, email, role
- 24-hour token expiration
- Refresh by logging in again

---

## Environment Variables

```
# MongoDB Connection
MONGODB_URI=mongodb://localhost:27017/majestic-marquee

# Server Configuration
PORT=3000
NODE_ENV=development

# Authentication Secrets (change in production!)
SESSION_SECRET=your-session-secret-key
JWT_SECRET=your-jwt-secret-key
```

Generate a strong JWT_SECRET:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## Scripts

```bash
# Start development server with auto-reload
npm run dev

# Start production server
npm start

# Seed database with users
npm run seed:users

# Seed database with services
npm run seed

# Seed everything at once
npm run seed:all
```

---

## Key Code Components

### Middleware
- `auth.js` - Session validation for web routes
- `api-auth.js` - JWT validation for API routes

### Helper Functions (api.js)
- `generateToken()` - Create JWT tokens
- `sendError()` - Standardized error responses
- `sendSuccess()` - Standardized success responses

### Model Methods
- `User.comparePassword()` - Password verification
- `Order.calculateTotal()` - Order total calculation

---

## Security Features

✅ Password hashing with bcryptjs  
✅ JWT token encryption  
✅ Session-based authentication  
✅ CSRF protection through session tokens  
✅ Input validation on all routes  
✅ Role-based access control  
✅ HTTP-only cookies in production  
✅ Environment variable protection  

---

## Common Tasks

### Add a New Service
1. Login as admin at http://localhost:3000/admin
2. Click "Add New Service"
3. Fill in service details
4. Submit form

### Create an API Client
1. Register user via `/api/v1/auth/register`
2. Login to get JWT token via `/api/v1/auth/login`
3. Use token in Authorization header for protected endpoints

### Filter Services
```
# By category
/services?category=Wedding

# By search
/services?search=Photography

# By page
/services?page=2&limit=5

# Combined
/services?page=1&category=Wedding&search=Luxury
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| MongoDB connection fails | Ensure MongoDB is running: `mongod` |
| Port 3000 already in use | Change PORT in .env or kill process |
| JWT token invalid | Check JWT_SECRET in .env matches signed token |
| Session expires quickly | Increase maxAge in server.js session config |
| Images not loading | Verify images are in `public/images/` folder |

---

## Project Status

✅ **Complete Features:**
- User authentication (web & API)
- Service management
- Order system
- Admin panel
- RESTful API
- Database integration
- Image gallery

---

## File Explanations

**server.js** - Main application entry point. Sets up Express, connects to MongoDB, configures middleware, and defines routes.

**package.json** - Lists all project dependencies and npm scripts for running the application.

**middleware/auth.js** - Contains session-based authentication middleware for protecting web routes.

**middleware/api-auth.js** - Contains JWT-based authentication middleware for protecting API endpoints.

**models/** - Mongoose schemas defining database structure for Users, Services, and Orders.

**routes/** - Express route handlers organized by feature (auth, admin, services, api).

**views/** - EJS template files that render HTML pages sent to the browser.

**public/** - Static files (CSS, JavaScript, images) served directly to clients.

**seed/** - Scripts to populate database with sample data for testing.

---

## Support & Documentation

For detailed API documentation, refer to inline comments in:
- `routes/api.js` - All API endpoints
- `middleware/api-auth.js` - JWT authentication details
- Model files - Database schema information

---

**Last Updated:** May 18, 2026  
**Version:** 1.0.0  
**Status:** Production Ready
