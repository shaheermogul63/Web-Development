// ==========================================
// SESSION-BASED AUTHENTICATION MIDDLEWARE
// ==========================================
// This file contains middleware functions for session-based user authentication
// Used for protecting routes that require user login (web interface)
// These middleware work with express-session cookies

// ==========================================
// MIDDLEWARE: Check if user is logged in
// ==========================================
// This middleware verifies that a user has an active session
// If not logged in, redirects to the login page with an error message
// Usage: app.use(isLoggedIn) or router.get('/protected', isLoggedIn, handler)
const isLoggedIn = (req, res, next) => {
  // Check if req.session.user exists (user is logged in)
  if (!req.session.user) {
    // Show error message and redirect to login
    req.flash('error', 'Please log in to access this page');
    return res.redirect('/auth/login');
  }
  // User is logged in, proceed to next middleware/route handler
  next();
};

// ==========================================
// MIDDLEWARE: Check if user is admin
// ==========================================
// This middleware checks two things:
// 1. User is logged in (has active session)
// 2. User has admin role
// If either check fails, redirects with appropriate error message
// Usage: app.use(isAdmin) or router.get('/admin', isAdmin, handler)
const isAdmin = (req, res, next) => {
  // First check if user is logged in
  if (!req.session.user) {
    req.flash('error', 'Please log in to access this page');
    return res.redirect('/auth/login');
  }

  // Check if logged-in user has admin role
  if (req.session.user.role !== 'admin') {
    req.flash('error', 'Access Denied: Admin privileges required. This area is restricted to administrators only.');
    return res.redirect('/');
  }

  // User is admin, proceed to next middleware/route handler
  next();
};

// ==========================================
// MIDDLEWARE: Redirect if already logged in
// ==========================================
// This middleware prevents logged-in users from accessing login/register pages
// If user is already logged in, redirects to homepage
// Usage: router.get('/login', alreadyLoggedIn, handler)
const alreadyLoggedIn = (req, res, next) => {
  // Check if user already has an active session
  if (req.session.user) {
    // User is already logged in, redirect to homepage
    return res.redirect('/');
  }
  // User is not logged in, allow access to login/register pages
  next();
};

// Export all middleware functions for use in route files
module.exports = {
  isLoggedIn,
  isAdmin,
  alreadyLoggedIn
};

