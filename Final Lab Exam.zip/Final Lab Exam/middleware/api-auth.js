// ==========================================
// API AUTHENTICATION MIDDLEWARE
// ==========================================
// This file contains middleware for JWT-based API authentication
// Used for stateless authentication with external clients (mobile apps, React frontends)

const jwt = require('jsonwebtoken');

// ==========================================
// MIDDLEWARE: Verify JWT Token
// ==========================================
// Extract JWT from Authorization header, verify it, and attach decoded user info to request
// Format: Authorization: Bearer <token>
const verifyToken = (req, res, next) => {
  try {
    // Get the token from Authorization header
    const authHeader = req.headers['authorization'];

    // Check if Authorization header exists
    if (!authHeader) {
      return res.status(401).json({
        success: false,
        message: 'Unauthorized: No authentication token provided',
        error: 'Missing Authorization header'
      });
    }

    // Extract token from "Bearer <token>" format
    const token = authHeader.startsWith('Bearer ')
      ? authHeader.slice(7) // Remove "Bearer " prefix
      : authHeader;

    // Verify the token using the JWT_SECRET from environment variables
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key-change-in-production');

    // Attach decoded user information to request object for use in controllers
    req.user = {
      id: decoded.user_id,
      role: decoded.role,
      email: decoded.email
    };

    // Proceed to next middleware/controller
    next();
  } catch (error) {
    // Handle different JWT errors
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Unauthorized: Token has expired',
        error: 'Token expired'
      });
    }

    if (error.name === 'JsonWebTokenError') {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: Invalid token',
        error: 'Invalid token signature or format'
      });
    }

    // Generic JWT verification error
    return res.status(403).json({
      success: false,
      message: 'Forbidden: Token verification failed',
      error: error.message
    });
  }
};

// ==========================================
// MIDDLEWARE: Verify Admin Role
// ==========================================
// Check if authenticated user has admin role
const verifyAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Forbidden: Admin access required',
      error: 'User does not have admin privileges'
    });
  }

  next();
};

// ==========================================
// MIDDLEWARE: Optional Token (for mixed public/protected endpoints)
// ==========================================
// Attempt to verify token but don't fail if missing (useful for endpoints that work for both authenticated and unauthenticated users)
const optionalVerifyToken = (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];

    if (authHeader) {
      const token = authHeader.startsWith('Bearer ')
        ? authHeader.slice(7)
        : authHeader;

      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key-change-in-production');

      req.user = {
        id: decoded.user_id,
        role: decoded.role,
        email: decoded.email
      };
    }

    next();
  } catch (error) {
    // Silently fail - user is not authenticated, but it's optional
    next();
  }
};

module.exports = {
  verifyToken,
  verifyAdmin,
  optionalVerifyToken
};
